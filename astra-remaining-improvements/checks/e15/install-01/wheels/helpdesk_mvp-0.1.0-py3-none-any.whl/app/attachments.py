"""Bounded uploads with rollback cleanup and authorized, contained downloads."""

import logging
import os
from pathlib import Path
import uuid

from fastapi import HTTPException
from sqlalchemy import event
from sqlalchemy.orm import Session

from app.config import MAX_ATTACHMENT_SIZE
from app.models import Attachment

log = logging.getLogger(__name__)
MAX_FILES = 3
TOTAL_LIMIT = 10 * 1024 * 1024


@event.listens_for(Session, "after_commit")
def uploads_committed(db):
    db.info.pop("new_uploads", None)


@event.listens_for(Session, "after_rollback")
def cleanup_rejected_uploads(db):
    for root, path in db.info.pop("new_uploads", []):
        try:
            if path.resolve().parent == root and path.name.endswith(".blob"):
                path.unlink(missing_ok=True)
        except OSError:
            log.exception(
                "Could not remove an uncommitted upload; run the storage audit."
            )


async def save_attachments(db, ticket, message, files, upload_dir):
    files = [item for item in files if item.filename]
    if len(files) > MAX_FILES:
        raise HTTPException(status_code=422, detail="Attach at most three files.")
    root = Path(upload_dir).resolve()
    root.mkdir(parents=True, exist_ok=True)
    total = 0
    for upload in files:
        name = upload.filename
        if (
            not isinstance(name, str)
            or not 1 <= len(name) <= 255
            or name in {".", ".."}
            or any(ord(c) < 32 or ord(c) == 127 or c in "/\\:" for c in name)
        ):
            raise HTTPException(
                status_code=422,
                detail="Attachment names must be short filenames without paths or control characters.",
            )
        try:
            name.encode("utf-8")
        except UnicodeError:
            raise HTTPException(
                status_code=422, detail="Attachment name contains invalid Unicode."
            )
        path = root / f"{uuid.uuid4().hex}.blob"
        size = 0
        with path.open("xb") as output:
            db.info.setdefault("new_uploads", []).append((root, path))
            while chunk := await upload.read(64 * 1024):
                size += len(chunk)
                total += len(chunk)
                if size > MAX_ATTACHMENT_SIZE or total > TOTAL_LIMIT:
                    raise HTTPException(
                        status_code=413,
                        detail="Files must be at most 5 MiB each and 10 MiB combined.",
                    )
                output.write(chunk)
            output.flush()
            os.fsync(output.fileno())
        message.attachments.append(
            Attachment(
                ticket_id=ticket.id,
                filename=name,
                content_type="application/octet-stream",
                size=size,
                storage_path=str(path),
            )
        )


def download_path(attachment, upload_dir):
    root = Path(upload_dir).resolve()
    path = Path(attachment.storage_path).resolve()
    if path.parent != root or not path.is_file():
        raise HTTPException(
            status_code=404,
            detail="Attachment file is unavailable. Ask staff to review the storage audit.",
        )
    if path.stat().st_size != attachment.size:
        raise HTTPException(
            status_code=409,
            detail="Attachment size differs from its record. Preserve the file for storage review.",
        )
    return path
