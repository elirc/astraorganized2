"""Validated, finite business-time arithmetic using elapsed UTC time."""

from datetime import datetime, time, timedelta, timezone
import re
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError


DEFAULT_SCHEDULE = {str(day): [["09:00", "17:00"]] for day in range(5)}
MAX_DAYS = 3660
MAX_MINUTES = 525600


class ScheduleError(ValueError):
    """A calendar or requested horizon cannot be evaluated safely."""


def parse_hhmm(value: str) -> time:
    if not isinstance(value, str) or not re.fullmatch(
        r"(?:[01][0-9]|2[0-3]):[0-5][0-9]", value
    ):
        raise ScheduleError("Business hours must use HH:MM in 24-hour time.")
    return time(int(value[:2]), int(value[3:]))


def ensure_schedule(schedule: dict | None) -> dict:
    if schedule is None:
        schedule = DEFAULT_SCHEDULE
    if (
        type(schedule) is not dict
        or not schedule
        or any(day not in {str(i) for i in range(7)} for day in schedule)
    ):
        raise ScheduleError(
            "Supply business-hour weekdays 0 through 6 and at least one working interval."
        )
    result = {}
    total = 0
    for day, windows in schedule.items():
        if type(windows) is not list or len(windows) > 8:
            raise ScheduleError("Each weekday supports at most eight time intervals.")
        ordered = []
        for window in windows:
            if type(window) is not list or len(window) != 2:
                raise ScheduleError(
                    "Each business interval needs a start and end time."
                )
            start, end = map(parse_hhmm, window)
            if start >= end:
                raise ScheduleError(
                    "Business intervals must end after they start on the same day."
                )
            ordered.append(list(window))
        ordered.sort(key=lambda window: window[0])
        if any(ordered[i][0] < ordered[i - 1][1] for i in range(1, len(ordered))):
            raise ScheduleError("Business-hour intervals must not overlap.")
        result[day] = ordered
        total += len(ordered)
    if total == 0:
        raise ScheduleError(
            "The calendar needs at least one working interval; an all-closed calendar cannot schedule an SLA."
        )
    return result


def get_timezone(name: str) -> ZoneInfo:
    if not isinstance(name, str) or not name or len(name) > 64:
        raise ScheduleError("Supply a valid IANA timezone name.")
    try:
        return ZoneInfo(name)
    except (ZoneInfoNotFoundError, ValueError) as error:
        raise ScheduleError(
            "Unknown business-hours timezone; review the calendar instead of silently using UTC."
        ) from error


def as_utc(value: datetime) -> datetime:
    if not isinstance(value, datetime):
        raise ScheduleError("Business-time inputs must be datetimes.")
    # SQLite's existing DateTime values may be naive; the stored convention is UTC.
    return (
        value.replace(tzinfo=timezone.utc) if value.tzinfo is None else value
    ).astimezone(timezone.utc)


def _boundary(day, clock, tz):
    local = datetime.combine(day, clock, tz).replace(fold=0)
    utc = local.astimezone(timezone.utc)
    if utc.astimezone(tz).replace(tzinfo=None) != local.replace(tzinfo=None):
        raise ScheduleError(
            "A business-hour boundary falls in a missing daylight-saving hour; review that calendar."
        )
    # An ambiguous clock boundary uses its earlier occurrence (fold=0).
    return utc


def _intervals(schedule, day, tz):
    return [
        (_boundary(day, parse_hhmm(start), tz), _boundary(day, parse_hhmm(end), tz))
        for start, end in schedule.get(str(day.weekday()), [])
    ]


def active_intervals_for_day(schedule: dict, day: datetime):
    if day.tzinfo is None:
        raise ScheduleError("A local calendar day needs a timezone.")
    return _intervals(ensure_schedule(schedule), day.date(), day.tzinfo)


def add_business_minutes(start: datetime, minutes: int, business_hours) -> datetime:
    if type(minutes) is not int or not 0 <= minutes <= MAX_MINUTES:
        raise ScheduleError(
            f"SLA durations must be whole minutes from 0 through {MAX_MINUTES}."
        )
    current = as_utc(start)
    schedule = ensure_schedule(business_hours.schedule_json)
    tz = get_timezone(business_hours.timezone)
    if minutes == 0:
        return current
    first_day = current.astimezone(tz).date()
    remaining = minutes * 60
    for offset in range(MAX_DAYS):
        try:
            day = first_day + timedelta(days=offset)
        except OverflowError as error:
            raise ScheduleError(
                "Business-time calculation exceeded the supported date range."
            ) from error
        for begin, end in _intervals(schedule, day, tz):
            begin = max(begin, current)
            seconds = (end - begin).total_seconds()
            if seconds <= 0:
                continue
            if remaining <= seconds:
                return begin + timedelta(seconds=remaining)
            remaining -= seconds
    raise ScheduleError(
        f"The requested SLA exceeds the {MAX_DAYS}-day calendar horizon."
    )


def business_minutes_between(
    start: datetime, end: datetime | None, business_hours
) -> int | None:
    if end is None:
        return None
    start, end = as_utc(start), as_utc(end)
    schedule = ensure_schedule(business_hours.schedule_json)
    tz = get_timezone(business_hours.timezone)
    if end <= start:
        return 0
    first_day, last_day = start.astimezone(tz).date(), end.astimezone(tz).date()
    days = (last_day - first_day).days + 1
    if days > MAX_DAYS:
        raise ScheduleError(
            f"The report interval exceeds the {MAX_DAYS}-day calendar horizon."
        )
    seconds = 0
    for offset in range(days):
        for begin, finish in _intervals(
            schedule, first_day + timedelta(days=offset), tz
        ):
            seconds += max(0, (min(finish, end) - max(begin, start)).total_seconds())
    return int(seconds // 60)
