from __future__ import annotations

from pathlib import Path
import os


BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = Path(os.environ.get("HELPDESK_DATA_DIR", BASE_DIR / "data")).resolve()
UPLOAD_DIR = (
    (DATA_DIR / "uploads")
    if "HELPDESK_DATA_DIR" in os.environ
    else BASE_DIR / "uploads"
)


def prepare_storage() -> None:
    """Create configured directories at application startup, never on module import."""
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    UPLOAD_DIR.mkdir(parents=True, exist_ok=True)


DATABASE_URL = f"sqlite:///{(DATA_DIR / 'helpdesk.db').as_posix()}"
SESSION_COOKIE = "helpdesk_session"
SESSION_TTL_DAYS = 14
MAX_ATTACHMENT_SIZE = 5 * 1024 * 1024
