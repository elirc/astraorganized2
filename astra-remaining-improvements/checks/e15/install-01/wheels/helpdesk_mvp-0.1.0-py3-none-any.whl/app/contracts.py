"""Strict, bounded request contracts. Validate before changing ORM objects."""

from typing import Annotated, Literal
import math
import re

from pydantic import (
    AfterValidator,
    BaseModel,
    ConfigDict,
    Field,
    ValidationError,
    model_validator,
)

from app.business_time import MAX_MINUTES, ensure_schedule, get_timezone


class ContractError(ValueError):
    pass


def bounded(value, depth=0):
    if depth > 6:
        raise ValueError("Request data exceeds six nested levels.")
    if isinstance(value, str):
        try:
            value.encode("utf-8")
        except UnicodeError as error:
            raise ValueError("Text contains an invalid Unicode sequence.") from error
        if len(value) > 20000 or any(
            ord(char) < 32 and char not in "\t\r\n" or ord(char) == 127
            for char in value
        ):
            raise ValueError(
                "Text is too long or contains unsupported control characters."
            )
    elif isinstance(value, dict):
        if len(value) > 100:
            raise ValueError("Objects support at most 100 fields.")
        for key, item in value.items():
            if not isinstance(key, str) or len(key) > 100:
                raise ValueError("Object field names must be short text.")
            bounded(key, depth + 1)
            bounded(item, depth + 1)
    elif isinstance(value, list):
        if len(value) > 100:
            raise ValueError("Lists support at most 100 entries.")
        for item in value:
            bounded(item, depth + 1)
    elif isinstance(value, float) and not math.isfinite(value):
        raise ValueError("Numbers must be finite.")


def line(value: str) -> str:
    if any(ord(char) < 32 or ord(char) == 127 for char in value):
        raise ValueError("This field must stay on one line.")
    value = value.strip()
    if not value:
        raise ValueError("This field must not be blank.")
    return value


def text(value: str) -> str:
    value = value.strip()
    if not value:
        raise ValueError("This field must not be blank.")
    return value


def email(value: str) -> str:
    value = line(value).lower()
    if not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", value):
        raise ValueError("Supply a valid email address.")
    return value


Id = Annotated[int, Field(ge=1, le=2147483647)]
Name = Annotated[str, Field(min_length=1, max_length=255), AfterValidator(line)]
Tag = Annotated[str, Field(min_length=1, max_length=64), AfterValidator(line)]
Body = Annotated[str, Field(min_length=1, max_length=20000), AfterValidator(text)]
Email = Annotated[str, Field(min_length=3, max_length=255), AfterValidator(email)]
Status = Literal["new", "open", "pending", "on_hold", "resolved", "closed", "spam"]
Priority = Literal["low", "normal", "high", "urgent"]
ChannelKind = Literal["email", "web", "api", "chat"]
EventKind = Literal["on_create", "on_update", "on_reply", "on_time_elapsed"]
Scalar = str | int | float | bool | None


class StrictBody(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True, allow_inf_nan=False)

    @model_validator(mode="before")
    @classmethod
    def bound_input(cls, value):
        bounded(value)
        return value


class TicketCreate(StrictBody):
    requester_id: Id
    subject: Name
    body: Body
    channel_id: Id | None = None
    team_id: Id | None = None
    priority: Priority = "normal"
    tags: list[Tag] = Field(default_factory=list, max_length=20)


class MessageBody(StrictBody):
    body: Body


class PortalIntake(StrictBody):
    name: Name
    email: Email
    subject: Name
    body: Body
    phone: Annotated[str, Field(max_length=64), AfterValidator(line)] | None = None
    company: Name | None = None


class EmailInbound(StrictBody):
    message_id: Name
    from_email: Email
    from_name: Name | None = None
    subject: Name | None = None
    body: Body
    headers: dict[str, Scalar] = Field(default_factory=dict)


class WebhookInbound(StrictBody):
    external_id: Name
    email: Email
    name: Name | None = None
    subject: Name | None = None
    body: Body


class TicketPatch(StrictBody):
    subject: Name | None = None
    status: Status | None = None
    priority: Priority | None = None
    team_id: Id | None = None
    assignee_id: Id | None = None
    type: Tag | None = None
    custom_fields: dict[str, Scalar] | None = None
    tags: list[Tag] | None = Field(default=None, max_length=20)

    @model_validator(mode="after")
    def require_changes(self):
        if not self.model_fields_set:
            raise ValueError("Supply at least one field to change.")
        for key in ["subject", "status", "priority", "custom_fields", "tags"]:
            if key in self.model_fields_set and getattr(self, key) is None:
                raise ValueError(f"{key} cannot be null.")
        return self


class Assignment(StrictBody):
    team_id: Id | None
    assignee_id: Id | None


class MergeTicket(StrictBody):
    source_ticket_id: Id


class MergeCustomer(StrictBody):
    source_customer_id: Id


class SplitTicket(StrictBody):
    message_ids: list[Id] = Field(min_length=1, max_length=100)

    @model_validator(mode="after")
    def unique_ids(self):
        if len(set(self.message_ids)) != len(self.message_ids):
            raise ValueError("Message identifiers must be unique.")
        return self


class CustomerBody(StrictBody):
    name: Name
    email: Email
    phone: Annotated[str, Field(max_length=64), AfterValidator(line)] | None = None
    company: Name | None = None
    notes: Annotated[str, Field(max_length=5000), AfterValidator(text)] | None = None


class TeamBody(StrictBody):
    name: Name
    description: Annotated[str, Field(max_length=2000), AfterValidator(text)] | None = (
        None
    )
    business_hours_id: Id | None = None
    member_ids: list[Id] = Field(default_factory=list, max_length=100)

    @model_validator(mode="after")
    def unique_members(self):
        if len(self.member_ids) != len(set(self.member_ids)):
            raise ValueError("Team members must be unique.")
        return self


class ChannelBody(StrictBody):
    name: Name
    type: ChannelKind
    address: Name | None = None
    signature: Annotated[str, Field(max_length=2000), AfterValidator(text)] | None = (
        None
    )
    routing_team_id: Id | None = None
    config: dict[str, Scalar] = Field(default_factory=dict)


class SLABody(StrictBody):
    name: Name
    business_hours_id: Id | None = None
    first_response_minutes: int = Field(default=60, ge=0, le=MAX_MINUTES)
    next_response_minutes: int = Field(default=240, ge=0, le=MAX_MINUTES)
    resolution_minutes: int = Field(default=480, ge=0, le=MAX_MINUTES)
    pause_on_pending: bool = True
    pause_on_hold: bool = True
    is_default: bool = False


class BusinessHoursBody(StrictBody):
    name: Name
    timezone: Annotated[str, Field(max_length=64), AfterValidator(line)] = "UTC"
    schedule: dict[str, list[list[str]]] | None = None

    @model_validator(mode="after")
    def validate_calendar(self):
        get_timezone(self.timezone)
        self.schedule = ensure_schedule(self.schedule)
        return self


class Conditions(StrictBody):
    status: list[Status] | None = None
    priority: list[Priority] | None = None
    channel: list[ChannelKind] | None = None
    team_id: list[Id] | None = None
    customer_id: list[Id] | None = None
    tags: list[Tag] | None = Field(default=None, max_length=20)
    text_match: Annotated[str, Field(max_length=255), AfterValidator(line)] | None = (
        None
    )


class Actions(StrictBody):
    set_status: Status | None = None
    set_priority: Priority | None = None
    assign_team_id: Id | None = None
    assign_agent_id: Id | None = None
    add_tags: list[Tag] | None = Field(default=None, max_length=20)
    remove_tags: list[Tag] | None = Field(default=None, max_length=20)
    send_canned_reply_id: Id | None = None

    @model_validator(mode="after")
    def has_action(self):
        if not any(getattr(self, key) is not None for key in self.model_fields_set):
            raise ValueError("An automation needs at least one action.")
        return self


class AutomationBody(StrictBody):
    name: Name
    event: EventKind
    enabled: bool = True
    position: int = Field(default=0, ge=0, le=10000)
    conditions: Conditions = Field(default_factory=Conditions)
    actions: Actions


class AutomationTest(StrictBody):
    ticket_id: Id
    event: EventKind
    context_text: Annotated[str, Field(max_length=20000)] = ""


class CannedBody(StrictBody):
    title: Name
    body_template: Body


def validate(payload, schema, *, patch=False):
    try:
        return schema.model_validate(payload).model_dump(
            exclude_unset=patch, exclude_none=not patch
        )
    except ValidationError as error:
        messages = [
            ".".join(str(part) for part in item["loc"]) + ": " + item["msg"]
            for item in error.errors(include_input=False)
        ]
        raise ContractError("; ".join(messages[:10])) from error
