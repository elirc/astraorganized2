from __future__ import annotations

from contextlib import contextmanager
from datetime import datetime, timezone

from fastapi import Request
from sqlalchemy import create_engine, event
from sqlalchemy.orm import DeclarativeBase, Session, sessionmaker

from app.config import DATABASE_URL


class Base(DeclarativeBase):
    pass


def create_db_engine(url: str):
    result = create_engine(url, connect_args={"check_same_thread": False}, future=True)

    @event.listens_for(result, "connect")
    def sqlite_options(connection, _record):
        cursor = connection.cursor()
        cursor.execute("PRAGMA foreign_keys=ON")
        cursor.execute("PRAGMA busy_timeout=5000")
        cursor.close()

    return result


engine = create_db_engine(DATABASE_URL)
SessionLocal = sessionmaker(
    bind=engine, autoflush=False, autocommit=False, expire_on_commit=False
)


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


@contextmanager
def session_scope() -> Session:
    session = SessionLocal()
    try:
        session.connection().exec_driver_sql("BEGIN IMMEDIATE")
        yield session
        session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()


def get_db(request: Request):
    db = SessionLocal()
    try:
        if request.method not in {"GET", "HEAD", "OPTIONS"}:
            # SQLite has one writer. Acquire it before reading a number or receipt,
            # while If-Match still protects a user's earlier reviewed version.
            db.connection().exec_driver_sql("BEGIN IMMEDIATE")
        yield db
    finally:
        if db.in_transaction():
            db.rollback()
        db.close()
