"""Bounded bodies and browser-origin checks before request parsing or database work."""

import json
import math
from urllib.parse import urlsplit

from starlette.responses import JSONResponse

JSON_LIMIT = 1024 * 1024
BODY_LIMIT = 12 * 1024 * 1024


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("JSON object field names must be unique.")
        result[key] = value
    return result


def reject_constant(_value):
    raise ValueError("JSON numbers must be finite.")


def finite_float(value):
    number = float(value)
    if not math.isfinite(number):
        raise ValueError("JSON numbers must be finite.")
    return number


class HttpBoundary:
    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        if scope["type"] != "http":
            return await self.app(scope, receive, send)
        headers = {key.lower(): value for key, value in scope.get("headers", [])}
        changing = scope.get("method", "GET") not in {"GET", "HEAD", "OPTIONS"}
        if changing:
            origin = headers.get(b"origin")
            if origin is not None:
                try:
                    parsed = urlsplit(origin.decode("ascii"))
                    valid = (
                        parsed.scheme == scope.get("scheme", "http")
                        and not parsed.username
                        and not parsed.password
                        and parsed.netloc.lower()
                        == headers.get(b"host", b"").decode("ascii").lower()
                        and parsed.path in {"", "/"}
                        and not parsed.query
                        and not parsed.fragment
                    )
                except (UnicodeError, ValueError):
                    valid = False
                if not valid:
                    return await JSONResponse(
                        {"detail": "Use the application from its own browser origin."},
                        status_code=403,
                    )(scope, receive, send)
            if headers.get(b"sec-fetch-site") == b"cross-site":
                return await JSONResponse(
                    {"detail": "Cross-site changes are not accepted."}, status_code=403
                )(scope, receive, send)
        if not changing:
            return await self.app(scope, receive, send)
        is_json = (
            headers.get(b"content-type", b"").split(b";", 1)[0].strip().lower()
            == b"application/json"
        )
        limit = JSON_LIMIT if is_json else BODY_LIMIT
        size, chunks = 0, []
        while True:
            message = await receive()
            if message["type"] == "http.disconnect":
                return
            chunk = message.get("body", b"")
            size += len(chunk)
            if size > limit:
                return await JSONResponse(
                    {"detail": f"Request exceeds the {limit}-byte limit."},
                    status_code=413,
                )(scope, receive, send)
            chunks.append(chunk)
            if not message.get("more_body", False):
                break
        body = b"".join(chunks)
        if is_json and body:
            try:
                value = json.loads(
                    body.decode("utf-8"),
                    object_pairs_hook=unique_object,
                    parse_constant=reject_constant,
                    parse_float=finite_float,
                )
                if not isinstance(value, dict):
                    raise ValueError("The JSON request must be an object.")
            except (ValueError, UnicodeError, RecursionError) as error:
                return await JSONResponse(
                    {"detail": "Invalid JSON request: " + str(error)[:200]},
                    status_code=422,
                )(scope, receive, send)
        first = True

        async def replay():
            nonlocal first
            if first:
                first = False
                return {"type": "http.request", "body": body, "more_body": False}
            return await receive()

        return await self.app(scope, replay, send)
