from __future__ import annotations

import uuid
import re
from contextlib import asynccontextmanager

from fastapi import (
    Depends,
    FastAPI,
    File,
    Form,
    HTTPException,
    Request,
    Response,
    UploadFile,
    Query,
    status,
)
from fastapi.responses import (
    HTMLResponse,
    JSONResponse,
    StreamingResponse,
    FileResponse,
)
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from starlette.middleware.trustedhost import TrustedHostMiddleware
from sqlalchemy.exc import IntegrityError, OperationalError
from sqlalchemy import func, or_, select
from sqlalchemy.orm import Session, joinedload
from sqlalchemy.orm.exc import StaleDataError

from app.config import BASE_DIR, SESSION_COOKIE, prepare_storage
import app.config as config
from app.migrations import migrate_database
from app.business_time import MAX_MINUTES, ScheduleError, ensure_schedule, get_timezone
from app import contracts
from app.http_boundary import HttpBoundary
from app import management
import app.services as services
from app.attachments import download_path
from app.references import referenced
from app.receipts import find_receipt, intake_receipt, operation_key, record_receipt
from app.db import Base, engine, get_db, utcnow
from app.models import (
    ApiToken,
    Attachment,
    AutomationEvent,
    AutomationRule,
    BusinessHours,
    CannedReply,
    Channel,
    ChannelType,
    Customer,
    InboundMessage,
    MessageKind,
    Role,
    SLA,
    Session as UserSession,
    Team,
    TeamMember,
    Ticket,
    TicketMessage,
    TicketFollower,
    TicketPriority,
    TicketStatus,
    TicketTagLink,
    User,
)
from app.permissions import (
    STAFF_ROLES,
    can_reply_externally,
    require_roles,
    require_staff,
)
from app.security import hash_token, new_token, session_expiry, verify_password
from app.services import (
    add_message,
    apply_ticket_updates,
    audit,
    build_ticket_filters,
    create_ticket,
    default_business_hours,
    get_or_create_customer,
    get_ticket,
    merge_customers,
    merge_tickets,
    report_csv,
    report_summary,
    require_ticket_access,
    run_automations,
    seed_database,
    serialize_ticket,
    split_ticket,
    staff_ticket_query,
)


templates = Jinja2Templates(directory=str(BASE_DIR / "app" / "templates"))


@asynccontextmanager
async def lifespan(_app: FastAPI):
    prepare_storage()
    migrate_database(engine, config.DATA_DIR / "migration-backups")
    yield


app = FastAPI(title="Help Desk MVP", lifespan=lifespan)
app.add_middleware(HttpBoundary)
app.add_middleware(
    TrustedHostMiddleware, allowed_hosts=["127.0.0.1", "localhost", "testserver"]
)
app.mount(
    "/static", StaticFiles(directory=str(BASE_DIR / "app" / "static")), name="static"
)


@app.exception_handler(ScheduleError)
async def calendar_error(_request: Request, error: ScheduleError):
    return JSONResponse(status_code=422, content={"detail": str(error)})


@app.exception_handler(StaleDataError)
async def concurrent_edit(_request: Request, _error: StaleDataError):
    return JSONResponse(
        status_code=409,
        content={
            "detail": "Another request changed this record. Reload and review your retained draft before trying again."
        },
    )


@app.exception_handler(contracts.ContractError)
async def invalid_contract(_request: Request, error: contracts.ContractError):
    return JSONResponse(status_code=422, content={"detail": str(error)})


@app.exception_handler(IntegrityError)
async def rejected_relationship(_request: Request, _error: IntegrityError):
    return JSONResponse(
        status_code=409,
        content={
            "detail": "The change conflicts with an existing name, receipt or referenced record. Your submitted work was not accepted."
        },
    )


@app.exception_handler(OperationalError)
async def storage_error(_request: Request, error: OperationalError):
    code = (getattr(error.orig, "sqlite_errorcode", 0) or 0) & 255
    if code in {5, 6}:
        return JSONResponse(
            status_code=503,
            content={
                "detail": "Local storage is busy. Retain your draft and retry the same operation."
            },
            headers={"Retry-After": "1"},
        )
    return JSONResponse(
        status_code=500,
        content={
            "detail": "Local storage could not complete this request. Retain your draft and inspect the server log."
        },
    )


def check_expected_version(request: Request, entity, header: str = "if-match") -> None:
    raw = request.headers.get(header)
    if raw is None:
        raise HTTPException(
            status_code=428,
            detail=f"Send {header} with the version you reviewed before changing this record.",
        )
    match = re.fullmatch(r'"?([1-9][0-9]{0,9})"?', raw)
    if not match or (raw.startswith('"') != raw.endswith('"')):
        raise HTTPException(
            status_code=422, detail="If-Match must contain one positive row version."
        )
    if int(match.group(1)) != entity.version:
        raise HTTPException(
            status_code=409,
            detail="This record changed since you loaded it. Reload and review your retained draft.",
        )


@app.middleware("http")
async def attach_request_id(request: Request, call_next):
    supplied = request.headers.get("x-request-id", "")
    request.state.request_id = (
        supplied
        if re.fullmatch(r"[A-Za-z0-9._-]{1,64}", supplied)
        else uuid.uuid4().hex
    )
    response = await call_next(request)
    response.headers["x-request-id"] = request.state.request_id
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["Referrer-Policy"] = "same-origin"
    response.headers["Cache-Control"] = "no-store"
    response.headers["Content-Security-Policy"] = (
        "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'"
    )
    return response


def resolve_token_user(db: Session, token: str | None) -> User | None:
    if not isinstance(token, str) or not token or len(token) > 512:
        return None
    token_hash = hash_token(token)
    session = db.scalar(
        select(UserSession)
        .where(UserSession.token_hash == token_hash, UserSession.expires_at > utcnow())
        .options(joinedload(UserSession.user).joinedload(User.teams))
    )
    if session and session.user.is_active:
        session.last_seen_at = utcnow()
        return session.user
    api_token = db.scalar(
        select(ApiToken)
        .where(
            ApiToken.token_hash == token_hash,
            or_(ApiToken.expires_at.is_(None), ApiToken.expires_at > utcnow()),
        )
        .options(joinedload(ApiToken.user).joinedload(User.teams))
    )
    if api_token and api_token.user.is_active:
        api_token.last_used_at = utcnow()
        return api_token.user
    return None


def get_current_user(request: Request, db: Session = Depends(get_db)) -> User:
    auth = request.headers.get("authorization")
    bearer = (
        auth.split(" ", 1)[1] if auth and auth.lower().startswith("bearer ") else None
    )
    cookie_token = request.cookies.get(SESSION_COOKIE)
    user = resolve_token_user(db, bearer or cookie_token)
    if not user or not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Authentication required"
        )
    return user


def get_optional_user(request: Request, db: Session = Depends(get_db)) -> User | None:
    auth = request.headers.get("authorization")
    bearer = (
        auth.split(" ", 1)[1] if auth and auth.lower().startswith("bearer ") else None
    )
    cookie_token = request.cookies.get(SESSION_COOKIE)
    user = resolve_token_user(db, bearer or cookie_token)
    return user if user and user.is_active else None


def get_staff_user(user: User = Depends(get_current_user)) -> User:
    require_staff(user)
    return user


def get_admin_user(user: User = Depends(get_current_user)) -> User:
    require_roles(user, Role.INSTANCE_ADMIN, Role.SUPPORT_MANAGER)
    return user


def get_customer_user(user: User = Depends(get_current_user)) -> User:
    require_roles(user, Role.CUSTOMER)
    return user


@app.get("/", response_class=HTMLResponse)
def home(request: Request, user: User | None = Depends(get_optional_user)):
    return templates.TemplateResponse("index.html", {"request": request, "user": user})


@app.get("/app", response_class=HTMLResponse)
def staff_workspace(request: Request, user: User = Depends(get_staff_user)):
    return templates.TemplateResponse("staff.html", {"request": request, "user": user})


@app.get("/admin", response_class=HTMLResponse)
def admin_workspace(request: Request, user: User = Depends(get_admin_user)):
    return templates.TemplateResponse("admin.html", {"request": request, "user": user})


@app.get("/portal", response_class=HTMLResponse)
def portal_workspace(request: Request, user: User | None = Depends(get_optional_user)):
    return templates.TemplateResponse("portal.html", {"request": request, "user": user})


@app.get("/health")
def health():
    return {"ok": True}


@app.post("/auth/login")
def login(
    payload: dict, request: Request, response: Response, db: Session = Depends(get_db)
):
    email = payload.get("email", "")
    password = payload.get("password", "")
    if not isinstance(email, str) or not isinstance(password, str) or len(email) > 255:
        raise HTTPException(status_code=401, detail="Invalid credentials")
    email = email.strip().lower()
    user = db.scalar(
        select(User).where(User.email == email).options(joinedload(User.teams))
    )
    if (
        not user
        or not user.is_active
        or not verify_password(password, user.password_hash)
    ):
        raise HTTPException(status_code=401, detail="Invalid credentials")
    token = new_token()
    db.add(
        UserSession(
            user_id=user.id,
            token_hash=hash_token(token),
            expires_at=session_expiry(),
            user_agent=request.headers.get("user-agent"),
            ip_address=request.client.host if request.client else None,
        )
    )
    db.commit()
    response.set_cookie(
        SESSION_COOKIE,
        token,
        httponly=True,
        samesite="lax",
        secure=request.url.scheme == "https",
        max_age=config.SESSION_TTL_DAYS * 86400,
    )
    return {
        "user": {
            "id": user.id,
            "email": user.email,
            "role": user.role.value,
            "full_name": user.full_name,
        }
    }


@app.post("/auth/logout")
def logout(
    request: Request,
    response: Response,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    token = request.cookies.get(SESSION_COOKIE)
    if token:
        session = db.scalar(
            select(UserSession).where(UserSession.token_hash == hash_token(token))
        )
        if session:
            db.delete(session)
            db.commit()
    response.delete_cookie(SESSION_COOKIE)
    return {"ok": True}


@app.get("/auth/me")
def me(user: User = Depends(get_current_user)):
    return {
        "id": user.id,
        "email": user.email,
        "role": user.role.value,
        "full_name": user.full_name,
        "customer_id": user.customer_id,
    }


@app.get("/tickets")
def list_tickets(
    view: str | None = None,
    status_value: str | None = None,
    priority: str | None = None,
    search: str | None = Query(default=None, max_length=255),
    page: int = Query(default=1, ge=1, le=100000),
    page_size: int = Query(default=20, ge=1, le=100),
    db: Session = Depends(get_db),
    user: User = Depends(get_staff_user),
):
    stmt = build_ticket_filters(
        staff_ticket_query(user),
        view=view,
        status_value=status_value,
        priority=priority,
        search=search,
        user=user,
    )
    total = db.scalar(select(func.count()).select_from(stmt.order_by(None).subquery()))
    tickets = (
        db.scalars(stmt.offset((page - 1) * page_size).limit(page_size)).unique().all()
    )
    return {
        "items": [
            serialize_ticket(ticket, include_messages=False) for ticket in tickets
        ],
        "page": page,
        "page_size": page_size,
        "total": total,
        "has_more": page * page_size < total,
    }


@app.get("/tickets/{ticket_id}")
def ticket_detail(
    ticket_id: int,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    ticket = get_ticket(db, ticket_id)
    require_ticket_access(ticket, user)
    return serialize_ticket(
        ticket, include_messages=True, staff_view=user.role in STAFF_ROLES
    )


@app.post("/tickets")
def ticket_create(
    payload: dict,
    request: Request,
    db: Session = Depends(get_db),
    user: User = Depends(get_staff_user),
):
    if not can_reply_externally(user):
        raise HTTPException(
            status_code=403, detail="This role cannot create staff tickets."
        )
    payload = contracts.validate(payload, contracts.TicketCreate)
    key = operation_key(request)
    source = f"staff:{user.id}"
    existing = find_receipt(db, source, key, payload)
    if existing is not None:
        return {"id": existing.id, "number": existing.number, "duplicate": True}
    requester = db.get(Customer, payload.get("requester_id"))
    if not requester:
        raise HTTPException(status_code=404, detail="Requester not found")
    channel = (
        referenced(db, Channel, payload.get("channel_id"), "Channel")
        if payload.get("channel_id")
        else db.scalar(select(Channel).where(Channel.type == ChannelType.WEB))
    )
    ticket = create_ticket(
        db,
        requester=requester,
        subject=payload["subject"],
        body=payload["body"],
        channel=channel,
        actor_user=user,
        team_id=payload.get("team_id"),
        priority=TicketPriority(payload.get("priority", TicketPriority.NORMAL.value)),
        tags=payload.get("tags") or [],
        metadata={"source": "staff_create"},
        request_id=request.state.request_id,
    )
    record_receipt(db, source, key, payload, ticket)
    db.commit()
    return serialize_ticket(get_ticket(db, ticket.id))


@app.patch("/tickets/{ticket_id}")
def ticket_update(
    ticket_id: int,
    payload: dict,
    request: Request,
    db: Session = Depends(get_db),
    user: User = Depends(get_staff_user),
):
    ticket = get_ticket(db, ticket_id)
    require_ticket_access(ticket, user)
    check_expected_version(request, ticket)
    updated = apply_ticket_updates(
        db, ticket, payload, actor_user=user, request_id=request.state.request_id
    )
    db.commit()
    return serialize_ticket(get_ticket(db, updated.id))


@app.post("/tickets/{ticket_id}/assign")
def ticket_assign(
    ticket_id: int,
    payload: dict,
    request: Request,
    db: Session = Depends(get_db),
    user: User = Depends(get_staff_user),
):
    payload = contracts.validate(payload, contracts.Assignment)
    ticket = get_ticket(db, ticket_id)
    require_ticket_access(ticket, user)
    check_expected_version(request, ticket)
    updated = apply_ticket_updates(
        db,
        ticket,
        {"team_id": payload.get("team_id"), "assignee_id": payload.get("assignee_id")},
        actor_user=user,
        request_id=request.state.request_id,
    )
    db.commit()
    return serialize_ticket(get_ticket(db, updated.id))


@app.post("/tickets/{ticket_id}/reply")
async def ticket_reply(
    ticket_id: int,
    request: Request,
    body: str = Form(...),
    files: list[UploadFile] = File(default=[]),
    db: Session = Depends(get_db),
    user: User = Depends(get_staff_user),
):
    if not can_reply_externally(user):
        raise HTTPException(
            status_code=403, detail="External replies are not allowed for this role"
        )
    ticket = get_ticket(db, ticket_id)
    require_ticket_access(ticket, user)
    check_expected_version(request, ticket)
    await add_message(
        db,
        ticket,
        body=body,
        kind=MessageKind.PUBLIC,
        actor_user=user,
        files=files,
        request_id=request.state.request_id,
    )
    db.commit()
    return serialize_ticket(get_ticket(db, ticket.id))


@app.post("/tickets/{ticket_id}/note")
async def ticket_note(
    ticket_id: int,
    request: Request,
    body: str = Form(...),
    files: list[UploadFile] = File(default=[]),
    db: Session = Depends(get_db),
    user: User = Depends(get_staff_user),
):
    ticket = get_ticket(db, ticket_id)
    require_ticket_access(ticket, user)
    check_expected_version(request, ticket)
    await add_message(
        db,
        ticket,
        body=body,
        kind=MessageKind.INTERNAL,
        actor_user=user,
        files=files,
        request_id=request.state.request_id,
    )
    db.commit()
    return serialize_ticket(get_ticket(db, ticket.id))


@app.post("/tickets/{ticket_id}/follow")
def ticket_follow(
    ticket_id: int,
    request: Request,
    db: Session = Depends(get_db),
    user: User = Depends(get_staff_user),
):
    ticket = get_ticket(db, ticket_id)
    require_ticket_access(ticket, user)
    check_expected_version(request, ticket)
    services.require_writable_ticket(ticket)
    existing = db.scalar(
        select(TicketFollower).where(
            TicketFollower.ticket_id == ticket.id, TicketFollower.user_id == user.id
        )
    )
    if not existing:
        ticket.updated_at = utcnow()
        db.add(TicketFollower(ticket_id=ticket.id, user_id=user.id))
        audit(
            db,
            entity_type="ticket",
            entity_id=str(ticket.id),
            action="followed",
            details={},
            actor_user=user,
            request_id=request.state.request_id,
        )
        db.commit()
    return {"ok": True}


@app.post("/tickets/{ticket_id}/unfollow")
def ticket_unfollow(
    ticket_id: int,
    request: Request,
    db: Session = Depends(get_db),
    user: User = Depends(get_staff_user),
):
    ticket = get_ticket(db, ticket_id)
    require_ticket_access(ticket, user)
    check_expected_version(request, ticket)
    services.require_writable_ticket(ticket)
    follower = db.scalar(
        select(TicketFollower).where(
            TicketFollower.ticket_id == ticket_id, TicketFollower.user_id == user.id
        )
    )
    if follower:
        ticket.updated_at = utcnow()
        db.delete(follower)
        audit(
            db,
            entity_type="ticket",
            entity_id=str(ticket_id),
            action="unfollowed",
            details={},
            actor_user=user,
            request_id=request.state.request_id,
        )
        db.commit()
    return {"ok": True}


@app.post("/tickets/{ticket_id}/merge")
def ticket_merge(
    ticket_id: int,
    payload: dict,
    request: Request,
    db: Session = Depends(get_db),
    user: User = Depends(get_staff_user),
):
    payload = contracts.validate(payload, contracts.MergeTicket)
    target = get_ticket(db, ticket_id)
    source = get_ticket(db, payload["source_ticket_id"])
    require_ticket_access(target, user)
    require_ticket_access(source, user)
    check_expected_version(request, target)
    check_expected_version(request, source, "if-match-source")
    merge_tickets(db, target, source, user, request.state.request_id)
    db.commit()
    return serialize_ticket(get_ticket(db, target.id))


@app.post("/tickets/{ticket_id}/split")
def ticket_split_route(
    ticket_id: int,
    payload: dict,
    request: Request,
    db: Session = Depends(get_db),
    user: User = Depends(get_staff_user),
):
    payload = contracts.validate(payload, contracts.SplitTicket)
    source = get_ticket(db, ticket_id)
    require_ticket_access(source, user)
    check_expected_version(request, source)
    new_ticket = split_ticket(
        db, source, payload.get("message_ids") or [], user, request.state.request_id
    )
    db.commit()
    return serialize_ticket(get_ticket(db, new_ticket.id))


@app.get("/customers")
def customer_list(
    search: str = Query(default="", max_length=255),
    page: int = Query(default=1, ge=1, le=100000),
    page_size: int = Query(default=20, ge=1, le=100),
    db: Session = Depends(get_db),
    user: User = Depends(get_staff_user),
):
    return management.list_records(db, "customers", page, page_size, search)


@app.post("/customers")
def customer_create(
    payload: dict,
    request: Request,
    db: Session = Depends(get_db),
    user: User = Depends(get_staff_user),
):
    if not can_reply_externally(user):
        raise HTTPException(
            status_code=403, detail="This role cannot create customers."
        )
    item = management.save_record(
        db, "customers", payload, user, request.state.request_id
    )
    db.commit()
    return management.serialize("customers", item)


@app.post("/customers/{customer_id}/merge")
def customer_merge(
    customer_id: int,
    payload: dict,
    request: Request,
    db: Session = Depends(get_db),
    user: User = Depends(get_admin_user),
):
    payload = contracts.validate(payload, contracts.MergeCustomer)
    target = db.get(Customer, customer_id)
    source = db.get(Customer, payload["source_customer_id"])
    if not target or not source:
        raise HTTPException(status_code=404, detail="Customer not found")
    check_expected_version(request, target)
    check_expected_version(request, source, "if-match-source")
    merge_customers(db, target, source, user, request.state.request_id)
    db.commit()
    return {"id": target.id, "email": target.email}


@app.get("/teams")
def team_list(db: Session = Depends(get_db), user: User = Depends(get_staff_user)):
    teams = (
        db.scalars(
            select(Team)
            .options(joinedload(Team.members).joinedload(TeamMember.user))
            .order_by(Team.name.asc())
        )
        .unique()
        .all()
    )
    return {
        "items": [
            {
                "id": team.id,
                "name": team.name,
                "description": team.description,
                "members": [
                    {"id": member.user.id, "name": member.user.full_name}
                    for member in team.members
                ],
            }
            for team in teams
        ]
    }


@app.post("/teams")
def team_create(
    payload: dict,
    request: Request,
    db: Session = Depends(get_db),
    user: User = Depends(get_admin_user),
):
    item = management.save_record(db, "teams", payload, user, request.state.request_id)
    db.commit()
    return management.serialize("teams", item)


@app.get("/channels")
def channel_list(db: Session = Depends(get_db), user: User = Depends(get_staff_user)):
    channels = db.scalars(select(Channel).order_by(Channel.name.asc())).all()
    return {
        "items": [
            {
                "id": channel.id,
                "name": channel.name,
                "type": channel.type.value,
                "address": channel.address,
            }
            for channel in channels
        ]
    }


@app.post("/channels")
def channel_create(
    payload: dict,
    request: Request,
    db: Session = Depends(get_db),
    user: User = Depends(get_admin_user),
):
    item = management.save_record(
        db, "channels", payload, user, request.state.request_id
    )
    db.commit()
    return management.serialize("channels", item)


@app.get("/slas")
def sla_list(db: Session = Depends(get_db), user: User = Depends(get_staff_user)):
    slas = db.scalars(
        select(SLA).options(joinedload(SLA.business_hours)).order_by(SLA.name.asc())
    ).all()
    return {
        "items": [
            {
                "id": sla.id,
                "name": sla.name,
                "first_response_minutes": sla.first_response_minutes,
                "next_response_minutes": sla.next_response_minutes,
                "resolution_minutes": sla.resolution_minutes,
                "pause_on_pending": sla.pause_on_pending,
                "pause_on_hold": sla.pause_on_hold,
                "business_hours": sla.business_hours.name
                if sla.business_hours
                else None,
            }
            for sla in slas
        ]
    }


@app.post("/slas")
def sla_create(
    payload: dict,
    request: Request,
    db: Session = Depends(get_db),
    user: User = Depends(get_admin_user),
):
    item = management.save_record(db, "slas", payload, user, request.state.request_id)
    db.commit()
    return management.serialize("slas", item)


@app.get("/business-hours")
def business_hours_list(
    db: Session = Depends(get_db), user: User = Depends(get_staff_user)
):
    items = db.scalars(select(BusinessHours).order_by(BusinessHours.name.asc())).all()
    return {
        "items": [
            {
                "id": item.id,
                "name": item.name,
                "timezone": item.timezone,
                "schedule": item.schedule_json,
            }
            for item in items
        ]
    }


@app.post("/business-hours")
def business_hours_create(
    payload: dict,
    request: Request,
    db: Session = Depends(get_db),
    user: User = Depends(get_admin_user),
):
    item = management.save_record(
        db, "business-hours", payload, user, request.state.request_id
    )
    db.commit()
    return management.serialize("business-hours", item)


@app.get("/automations")
def automation_list(
    db: Session = Depends(get_db), user: User = Depends(get_staff_user)
):
    rules = db.scalars(
        select(AutomationRule).order_by(
            AutomationRule.position.asc(), AutomationRule.id.asc()
        )
    ).all()
    return {
        "items": [
            {
                "id": rule.id,
                "name": rule.name,
                "event": rule.event.value,
                "enabled": rule.enabled,
                "conditions": rule.conditions_json,
                "actions": rule.actions_json,
            }
            for rule in rules
        ]
    }


@app.post("/automations")
def automation_create(
    payload: dict,
    request: Request,
    db: Session = Depends(get_db),
    user: User = Depends(get_admin_user),
):
    item = management.save_record(
        db, "automations", payload, user, request.state.request_id
    )
    db.commit()
    return management.serialize("automations", item)


@app.post("/automations/test")
def automation_test(
    payload: dict,
    request: Request,
    db: Session = Depends(get_db),
    user: User = Depends(get_admin_user),
):
    payload = contracts.validate(payload, contracts.AutomationTest)
    ticket = get_ticket(db, payload["ticket_id"])
    require_ticket_access(ticket, user)
    check_expected_version(request, ticket)
    services.require_writable_ticket(ticket)
    run_automations(
        db,
        AutomationEvent(payload["event"]),
        ticket,
        actor_user=user,
        context_text=payload.get("context_text", ""),
    )
    db.commit()
    return serialize_ticket(get_ticket(db, ticket.id))


@app.get("/canned-replies")
def canned_reply_list(
    db: Session = Depends(get_db), user: User = Depends(get_staff_user)
):
    items = db.scalars(select(CannedReply).order_by(CannedReply.title.asc())).all()
    return {
        "items": [
            {"id": item.id, "title": item.title, "body_template": item.body_template}
            for item in items
        ]
    }


@app.post("/canned-replies")
def canned_reply_create(
    payload: dict,
    request: Request,
    db: Session = Depends(get_db),
    user: User = Depends(get_admin_user),
):
    item = management.save_record(
        db, "canned-replies", payload, user, request.state.request_id
    )
    db.commit()
    return management.serialize("canned-replies", item)


@app.get("/reports/summary")
def reports_summary(
    db: Session = Depends(get_db), user: User = Depends(get_staff_user)
):
    return report_summary(db, user)


@app.get("/reports/export")
def reports_export(db: Session = Depends(get_db), user: User = Depends(get_staff_user)):
    content = report_csv(db, user)
    return StreamingResponse(
        iter([content]),
        media_type="text/csv",
        headers={"content-disposition": "attachment; filename=report.csv"},
    )


@app.get("/portal/tickets")
def portal_ticket_list(
    page: int = Query(default=1, ge=1, le=100000),
    page_size: int = Query(default=20, ge=1, le=100),
    db: Session = Depends(get_db),
    user: User = Depends(get_customer_user),
):
    stmt = select(Ticket).where(
        Ticket.requester_id == user.customer_id, Ticket.deleted.is_(False)
    )
    total = db.scalar(select(func.count()).select_from(stmt.subquery()))
    tickets = db.scalars(
        stmt.order_by(Ticket.updated_at.desc(), Ticket.id.desc())
        .offset((page - 1) * page_size)
        .limit(page_size)
    ).all()
    return {
        "items": [
            serialize_ticket(ticket, include_messages=False, staff_view=False)
            for ticket in tickets
        ],
        "page": page,
        "page_size": page_size,
        "total": total,
        "has_more": page * page_size < total,
    }


@app.get("/portal/tickets/{ticket_id}")
def portal_ticket_detail(
    ticket_id: int,
    db: Session = Depends(get_db),
    user: User = Depends(get_customer_user),
):
    ticket = get_ticket(db, ticket_id)
    if ticket.requester_id != user.customer_id:
        raise HTTPException(status_code=403, detail="Ticket access denied")
    return serialize_ticket(ticket, include_messages=True, staff_view=False)


@app.post("/portal/tickets")
def portal_ticket_create(
    request: Request,
    subject: str = Form(...),
    body: str = Form(...),
    name: str = Form(...),
    email: str = Form(...),
    phone: str | None = Form(default=None),
    company: str | None = Form(default=None),
    db: Session = Depends(get_db),
):
    if not db.scalar(
        select(User.id)
        .where(User.role == Role.INSTANCE_ADMIN, User.is_active.is_(True))
        .limit(1)
    ):
        raise HTTPException(
            status_code=503,
            detail="The help desk has not been initialized. Ask its owner to complete local account setup.",
        )
    payload = contracts.validate(
        dict(
            name=name,
            email=email,
            subject=subject,
            body=body,
            phone=phone,
            company=company,
        ),
        contracts.PortalIntake,
    )
    key = operation_key(request)
    existing = find_receipt(db, "portal", key, payload)
    if existing is not None:
        return intake_receipt(existing)
    customer = get_or_create_customer(
        db,
        name=payload["name"],
        email=payload["email"],
        phone=payload.get("phone"),
        company=payload.get("company"),
    )
    channel = db.scalar(select(Channel).where(Channel.type == ChannelType.WEB))
    ticket = create_ticket(
        db,
        requester=customer,
        subject=payload["subject"],
        body=payload["body"],
        channel=channel,
        metadata={"source": "portal", "identity_verified": False},
        request_id=request.state.request_id,
    )
    record_receipt(db, "portal", key, payload, ticket)
    db.commit()
    return intake_receipt(ticket)


@app.post("/portal/tickets/{ticket_id}/reply")
async def portal_ticket_reply(
    ticket_id: int,
    request: Request,
    body: str = Form(...),
    files: list[UploadFile] = File(default=[]),
    db: Session = Depends(get_db),
    user: User = Depends(get_customer_user),
):
    ticket = get_ticket(db, ticket_id)
    if ticket.requester_id != user.customer_id:
        raise HTTPException(status_code=403, detail="Ticket access denied")
    check_expected_version(request, ticket)
    await add_message(
        db,
        ticket,
        body=body,
        kind=MessageKind.PUBLIC,
        actor_customer=user.customer,
        files=files,
        request_id=request.state.request_id,
    )
    db.commit()
    return serialize_ticket(get_ticket(db, ticket.id), staff_view=False)


@app.post("/integrations/inbound/email")
def inbound_email(
    payload: dict,
    request: Request,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    require_roles(user, Role.INTEGRATION_BOT, Role.INSTANCE_ADMIN, Role.SUPPORT_MANAGER)
    payload = contracts.validate(payload, contracts.EmailInbound)
    external_id = payload["message_id"]
    ticket = find_receipt(db, "email", external_id, payload)
    if ticket is not None:
        return {
            "duplicate": True,
            "ticket_id": ticket.id,
            "ticket_number": ticket.number,
        }
    customer = get_or_create_customer(
        db, payload.get("from_name") or payload["from_email"], payload["from_email"]
    )
    channel = db.scalar(select(Channel).where(Channel.type == ChannelType.EMAIL))
    ticket = create_ticket(
        db,
        requester=customer,
        subject=payload.get("subject") or f"Email from {customer.email}",
        body=payload.get("body") or "",
        channel=channel,
        metadata={
            "headers": payload.get("headers") or {},
            "message_id": external_id,
            "identity_verified": False,
        },
        request_id=request.state.request_id,
    )
    record_receipt(db, "email", external_id, payload, ticket)
    db.commit()
    return {"duplicate": False, "ticket_id": ticket.id, "ticket_number": ticket.number}


@app.post("/integrations/inbound/webhook")
def inbound_webhook(
    payload: dict,
    request: Request,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    require_roles(user, Role.INTEGRATION_BOT, Role.INSTANCE_ADMIN, Role.SUPPORT_MANAGER)
    payload = contracts.validate(payload, contracts.WebhookInbound)
    external_id = payload["external_id"]
    ticket = find_receipt(db, "webhook", external_id, payload)
    if ticket is not None:
        return {"duplicate": True, "ticket_id": ticket.id}
    customer = get_or_create_customer(
        db, payload.get("name") or payload["email"], payload["email"]
    )
    channel = db.scalar(select(Channel).where(Channel.type == ChannelType.API))
    ticket = create_ticket(
        db,
        requester=customer,
        subject=payload.get("subject") or "Webhook ticket",
        body=payload.get("body") or "",
        channel=channel,
        metadata={"external_id": external_id, "identity_verified": False},
        request_id=request.state.request_id,
    )
    record_receipt(db, "webhook", external_id, payload, ticket)
    db.commit()
    return {"duplicate": False, "ticket_id": ticket.id}


@app.get("/data/bootstrap")
def bootstrap_data(
    db: Session = Depends(get_db), user: User = Depends(get_current_user)
):
    if user.role in STAFF_ROLES:
        teams = db.scalars(select(Team).order_by(Team.name.asc())).all()
        users = db.scalars(
            select(User)
            .where(
                User.role.in_(
                    [
                        Role.INSTANCE_ADMIN,
                        Role.SUPPORT_MANAGER,
                        Role.AGENT,
                        Role.LIGHT_AGENT,
                    ]
                ),
                User.is_active.is_(True),
            )
            .order_by(User.full_name.asc())
        ).all()
        canned = db.scalars(select(CannedReply).order_by(CannedReply.title.asc())).all()
        return {
            "teams": [{"id": team.id, "name": team.name} for team in teams],
            "users": [
                {"id": item.id, "name": item.full_name, "role": item.role.value}
                for item in users
            ],
            "canned_replies": [
                {
                    "id": item.id,
                    "title": item.title,
                    "body_template": item.body_template,
                }
                for item in canned
            ],
            "me": {"id": user.id, "full_name": user.full_name, "role": user.role.value},
        }
    return {"me": {"id": user.id, "full_name": user.full_name, "role": user.role.value}}


@app.get("/manage/{kind}")
def manage_list(
    kind: str,
    page: int = Query(default=1, ge=1, le=100000),
    page_size: int = Query(default=20, ge=1, le=100),
    search: str = Query(default="", max_length=255),
    db: Session = Depends(get_db),
    user: User = Depends(get_admin_user),
):
    return management.list_records(db, kind, page, page_size, search)


@app.get("/manage/{kind}/{identifier}")
def manage_detail(
    kind: str,
    identifier: int,
    db: Session = Depends(get_db),
    user: User = Depends(get_admin_user),
):
    return management.serialize(kind, management.get_record(db, kind, identifier))


@app.post("/manage/{kind}")
def manage_create(
    kind: str,
    payload: dict,
    request: Request,
    db: Session = Depends(get_db),
    user: User = Depends(get_admin_user),
):
    item = management.save_record(db, kind, payload, user, request.state.request_id)
    db.commit()
    return management.serialize(kind, item)


@app.put("/manage/{kind}/{identifier}")
def manage_update(
    kind: str,
    identifier: int,
    payload: dict,
    request: Request,
    db: Session = Depends(get_db),
    user: User = Depends(get_admin_user),
):
    item = management.get_record(db, kind, identifier)
    check_expected_version(request, item)
    management.save_record(db, kind, payload, user, request.state.request_id, item)
    db.commit()
    return management.serialize(kind, item)


@app.delete("/manage/{kind}/{identifier}")
def manage_delete(
    kind: str,
    identifier: int,
    request: Request,
    db: Session = Depends(get_db),
    user: User = Depends(get_admin_user),
):
    item = management.get_record(db, kind, identifier)
    check_expected_version(request, item)
    management.delete_record(db, kind, item, user, request.state.request_id)
    db.commit()
    return {"deleted": True, "id": identifier}


@app.delete("/tickets/{ticket_id}")
def ticket_delete(
    ticket_id: int,
    request: Request,
    db: Session = Depends(get_db),
    user: User = Depends(get_admin_user),
):
    ticket = get_ticket(db, ticket_id)
    check_expected_version(request, ticket)
    services.require_writable_ticket(ticket)
    ticket.deleted = True
    ticket.updated_at = utcnow()
    services.refresh_sla(ticket, db)
    audit(
        db,
        entity_type="ticket",
        entity_id=str(ticket.id),
        action="soft_deleted",
        details={},
        actor_user=user,
        request_id=request.state.request_id,
    )
    db.commit()
    return {"deleted": True, "id": ticket.id, "version": ticket.version}


@app.get("/attachments/{attachment_id}")
def attachment_download(
    attachment_id: int,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    attachment = db.get(Attachment, attachment_id)
    if (
        not attachment
        or not attachment.message
        or attachment.message.ticket_id != attachment.ticket_id
    ):
        raise HTTPException(status_code=404, detail="Attachment not found.")
    ticket = get_ticket(db, attachment.ticket_id)
    require_ticket_access(ticket, user)
    if user.role == Role.CUSTOMER and attachment.message.kind != MessageKind.PUBLIC:
        raise HTTPException(
            status_code=403,
            detail="Internal attachments are not available to customers.",
        )
    path = download_path(attachment, services.UPLOAD_DIR)
    return FileResponse(
        path,
        media_type="application/octet-stream",
        filename=attachment.filename,
        content_disposition_type="attachment",
        headers={"X-Content-Type-Options": "nosniff"},
    )
