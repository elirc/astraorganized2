"""Small explicit resource registry for versioned administration CRUD."""

from fastapi import HTTPException
from sqlalchemy import func, select, or_

from app import contracts
from app.models import (
    AutomationEvent,
    AutomationRule,
    BusinessHours,
    CannedReply,
    Channel,
    ChannelType,
    Customer,
    Role,
    SLA,
    Team,
    TeamMember,
    Ticket,
    User,
)
from app.references import FULL_STAFF, assignment, referenced
from app.services import audit, default_business_hours


RESOURCES = {
    "customers": (
        Customer,
        contracts.CustomerBody,
        {
            "name": "name",
            "email": "email",
            "phone": "phone",
            "company": "company",
            "notes": "notes",
        },
    ),
    "teams": (
        Team,
        contracts.TeamBody,
        {
            "name": "name",
            "description": "description",
            "business_hours_id": "business_hours_id",
        },
    ),
    "channels": (
        Channel,
        contracts.ChannelBody,
        {
            "name": "name",
            "type": "type",
            "address": "address",
            "signature": "signature",
            "routing_team_id": "routing_team_id",
            "config": "config_json",
        },
    ),
    "slas": (
        SLA,
        contracts.SLABody,
        {
            field: field
            for field in [
                "name",
                "business_hours_id",
                "first_response_minutes",
                "next_response_minutes",
                "resolution_minutes",
                "pause_on_pending",
                "pause_on_hold",
                "is_default",
            ]
        },
    ),
    "business-hours": (
        BusinessHours,
        contracts.BusinessHoursBody,
        {"name": "name", "timezone": "timezone", "schedule": "schedule_json"},
    ),
    "automations": (
        AutomationRule,
        contracts.AutomationBody,
        {
            "name": "name",
            "event": "event",
            "enabled": "enabled",
            "position": "position",
            "conditions": "conditions_json",
            "actions": "actions_json",
        },
    ),
    "canned-replies": (
        CannedReply,
        contracts.CannedBody,
        {"title": "title", "body_template": "body_template"},
    ),
}


def resource(kind):
    if kind not in RESOURCES:
        raise HTTPException(status_code=404, detail="Unknown resource.")
    return RESOURCES[kind]


def get_record(db, kind, identifier):
    model, _, _ = resource(kind)
    item = db.get(model, identifier)
    if item is None:
        raise HTTPException(status_code=404, detail="Record not found.")
    return item


def serialize(kind, item):
    _, _, fields = resource(kind)
    result = {"id": item.id, "version": item.version}
    for api, column in fields.items():
        value = getattr(item, column)
        result[api] = value.value if hasattr(value, "value") else value
    if kind == "teams":
        result["member_ids"] = [member.user_id for member in item.members]
        result["members"] = [
            {"id": member.user_id, "name": member.user.full_name}
            for member in item.members
        ]
    return result


def list_records(db, kind, page=1, page_size=20, search=""):
    model, _, _ = resource(kind)
    label = model.title if kind == "canned-replies" else model.name
    stmt = select(model)
    if search:
        match = func.lower(label).contains(search.lower(), autoescape=True)
        if kind == "customers":
            match = or_(
                match,
                func.lower(Customer.email).contains(search.lower(), autoescape=True),
            )
        stmt = stmt.where(match)
    total = db.scalar(select(func.count()).select_from(stmt.subquery()))
    items = db.scalars(
        stmt.order_by(label, model.id).offset((page - 1) * page_size).limit(page_size)
    ).all()
    return {
        "items": [serialize(kind, item) for item in items],
        "total": total,
        "page": page,
        "page_size": page_size,
        "has_more": page * page_size < total,
    }


def validate_references(db, kind, payload, item=None):
    if "business_hours_id" in payload:
        if payload["business_hours_id"] is None:
            payload["business_hours_id"] = default_business_hours(db).id
        referenced(db, BusinessHours, payload["business_hours_id"], "Business hours")
    if kind in {"teams", "slas"} and "business_hours_id" not in payload:
        payload["business_hours_id"] = default_business_hours(db).id
    if kind == "teams":
        for identifier in payload["member_ids"]:
            user = referenced(db, User, identifier, "Team member")
            if not user.is_active or user.role not in FULL_STAFF | {Role.LIGHT_AGENT}:
                raise HTTPException(
                    status_code=422, detail="Team members must be active staff."
                )
        if item:
            assigned = db.scalars(
                select(Ticket).where(
                    Ticket.team_id == item.id, Ticket.assignee_id.is_not(None)
                )
            ).all()
            if any(
                ticket.assignee.role == Role.AGENT
                and ticket.assignee_id not in payload["member_ids"]
                for ticket in assigned
            ):
                raise HTTPException(
                    status_code=409,
                    detail="Reassign this team's tickets before removing their assigned agent.",
                )
    if kind == "channels":
        referenced(db, Team, payload.get("routing_team_id"), "Routing team")
    if kind == "slas":
        other = db.scalar(
            select(SLA).where(
                SLA.is_default.is_(True), SLA.id != (item.id if item else -1)
            )
        )
        if payload["is_default"] and other:
            raise HTTPException(
                status_code=409,
                detail="A default SLA already exists. Edit that policy; multiple defaults are not accepted.",
            )
        if item and item.is_default and not payload["is_default"]:
            raise HTTPException(
                status_code=409,
                detail="Keep the existing default policy enabled; change its values instead.",
            )
    if kind == "customers":
        duplicate = db.scalar(
            select(Customer.id).where(
                func.lower(Customer.email) == payload["email"],
                Customer.id != (item.id if item else -1),
            )
        )
        if duplicate:
            raise HTTPException(
                status_code=409,
                detail="That email already belongs to a customer. Review the existing profile.",
            )
        if (
            item
            and item.email.lower() != payload["email"]
            and db.scalar(select(User.id).where(User.customer_id == item.id))
        ):
            raise HTTPException(
                status_code=409,
                detail="This customer has a sign-in identity. Email reassignment requires a separate verified identity workflow.",
            )
    if kind == "automations":
        conditions, actions = payload["conditions"], payload["actions"]
        for identifier in conditions.get("team_id") or []:
            referenced(db, Team, identifier, "Condition team")
        for identifier in conditions.get("customer_id") or []:
            referenced(db, Customer, identifier, "Condition customer")
        assignment(db, actions.get("assign_team_id"), actions.get("assign_agent_id"))
        referenced(db, CannedReply, actions.get("send_canned_reply_id"), "Canned reply")


def save_record(db, kind, body, user, request_id, item=None):
    model, schema, fields = resource(kind)
    # Full PUT contract: omitted optional fields are cleared, not silently preserved.
    payload = contracts.validate(body, schema)
    normalized = schema.model_validate(payload).model_dump()
    name_field = "title" if kind == "canned-replies" else "name"
    label = getattr(model, name_field)
    if db.scalar(
        select(model.id).where(
            func.lower(label) == normalized[name_field].lower(),
            model.id != (item.id if item else -1),
        )
    ):
        raise HTTPException(
            status_code=409,
            detail="That name already exists. Review its record before creating another operation.",
        )
    validate_references(db, kind, normalized, item)
    creating = item is None
    item = item or model()
    for api, column in fields.items():
        value = normalized[api]
        if kind == "channels" and api == "type":
            value = ChannelType(value)
        if kind == "automations" and api == "event":
            value = AutomationEvent(value)
        setattr(item, column, value)
    db.add(item)
    db.flush()
    if kind == "teams":
        wanted = set(normalized["member_ids"])
        existing = {member.user_id: member for member in item.members}
        for identifier in existing.keys() - wanted:
            item.members.remove(existing[identifier])
        for identifier in wanted - existing.keys():
            item.members.append(TeamMember(user_id=identifier))
        if not creating:
            item.version += 1  # membership-only edits also participate in CAS
    db.flush()
    audit(
        db,
        entity_type=kind,
        entity_id=str(item.id),
        action="created" if creating else "updated",
        details={"fields": list(fields)},
        actor_user=user,
        request_id=request_id,
    )
    return item


def delete_record(db, kind, item, user, request_id):
    if kind == "slas" and item.is_default:
        raise HTTPException(
            status_code=409, detail="The default SLA is required and cannot be deleted."
        )
    if kind == "business-hours" and item.name == "Default Business Hours":
        raise HTTPException(
            status_code=409,
            detail="The fallback calendar is required and cannot be deleted.",
        )
    # JSON conditions/actions are not protected by SQL foreign keys.
    for rule in db.scalars(select(AutomationRule)).all():
        conditions, actions = rule.conditions_json or {}, rule.actions_json or {}
        used = (
            kind == "teams"
            and (
                item.id in (conditions.get("team_id") or [])
                or actions.get("assign_team_id") == item.id
            )
            or kind == "customers"
            and item.id in (conditions.get("customer_id") or [])
            or kind == "canned-replies"
            and actions.get("send_canned_reply_id") == item.id
        )
        if used:
            raise HTTPException(
                status_code=409,
                detail="An automation references this record. Update that rule before deleting it.",
            )
    audit(
        db,
        entity_type=kind,
        entity_id=str(item.id),
        action="deleted",
        details={},
        actor_user=user,
        request_id=request_id,
    )
    db.delete(item)
    db.flush()
