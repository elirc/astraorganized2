"""One additive SQLite migration, with a consistent pre-migration backup."""

from datetime import datetime, timezone
from contextlib import closing
from pathlib import Path
import os
import sqlite3
import time
import uuid

from app.db import Base

SCHEMA_VERSION = 1
VERSION_TABLES = (
    "business_hours",
    "teams",
    "customers",
    "channels",
    "slas",
    "tickets",
    "automation_rules",
    "canned_replies",
)


class MigrationError(RuntimeError):
    pass


def _backup(database: Path, destination: Path) -> Path:
    destination.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    final = destination / f"helpdesk-before-v1-{stamp}-{uuid.uuid4().hex}.sqlite3"
    partial = final.with_suffix(".partial.sqlite3")
    fd = os.open(partial, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    os.close(fd)
    started = time.monotonic()

    def progress(_status, _remaining, _total):
        if time.monotonic() - started > 60:
            raise MigrationError(
                "Backup exceeded 60 seconds; the database was not migrated. Review the partial backup separately."
            )

    # A separate read connection can back up the accepted database while the writer
    # holds BEGIN IMMEDIATE. Backing up the writer itself can wait on its own lock.
    with closing(
        sqlite3.connect(database.as_uri() + "?mode=ro", uri=True, timeout=5)
    ) as reader:
        with closing(sqlite3.connect(partial)) as target:
            reader.backup(target, pages=128, progress=progress, sleep=0.01)
            if target.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
                raise MigrationError(
                    "Backup integrity check failed; migration was not started."
                )
    with partial.open("r+b") as saved:
        os.fsync(saved.fileno())
    if final.exists():
        raise MigrationError("Backup destination unexpectedly exists.")
    partial.rename(final)
    return final


def migrate_database(engine, backup_dir: Path) -> dict:
    if engine.dialect.name != "sqlite" or engine.url.database in (None, "", ":memory:"):
        raise MigrationError(
            "This migration supports a file-backed SQLite database only."
        )
    database = Path(engine.url.database).resolve()
    database.parent.mkdir(parents=True, exist_ok=True)
    backup = None
    with engine.connect() as connection:
        connection.exec_driver_sql("PRAGMA foreign_keys=ON")
        connection.exec_driver_sql("PRAGMA busy_timeout=5000")
        connection.commit()
        connection.exec_driver_sql("BEGIN IMMEDIATE")
        try:
            version = connection.exec_driver_sql("PRAGMA user_version").scalar_one()
            if version not in (0, SCHEMA_VERSION):
                raise MigrationError(
                    "The database schema version is unsupported; no downgrade or reset was attempted."
                )
            tables = {
                row[0]
                for row in connection.exec_driver_sql(
                    "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
                )
            }
            if not tables:
                Base.metadata.create_all(connection)
                connection.exec_driver_sql(f"PRAGMA user_version={SCHEMA_VERSION}")
                connection.commit()
                return {
                    "created": True,
                    "migrated": False,
                    "backup": None,
                    "version": SCHEMA_VERSION,
                }
            expected_tables = set(Base.metadata.tables)
            if not expected_tables.issubset(tables):
                raise MigrationError(
                    "The database is missing known help desk tables. Preserve it and review its schema manually."
                )
            columns = {}
            for name, table in Base.metadata.tables.items():
                columns[name] = {
                    row[1]
                    for row in connection.exec_driver_sql(
                        f'PRAGMA table_info("{name}")'
                    )
                }
                expected = set(table.columns.keys())
                allowed = [expected]
                if version == 0:
                    additions = {"version"} if name in VERSION_TABLES else set()
                    if name == "inbound_messages":
                        additions.add("fingerprint")
                    allowed.append(expected - additions)
                if columns[name] not in allowed:
                    raise MigrationError(
                        f"Table {name} has an unsupported layout; no columns were removed or reset."
                    )
            if (
                connection.exec_driver_sql("PRAGMA foreign_key_check").first()
                is not None
            ):
                raise MigrationError(
                    "Existing foreign-key violations need manual review before migration."
                )
            if (
                connection.exec_driver_sql("PRAGMA integrity_check").scalar_one()
                != "ok"
            ):
                raise MigrationError(
                    "Database integrity check failed; migration was not attempted."
                )
            for name in VERSION_TABLES:
                if (
                    "version" in columns[name]
                    and connection.exec_driver_sql(
                        f'SELECT 1 FROM "{name}" WHERE version IS NULL OR version < 1 LIMIT 1'
                    ).first()
                ):
                    raise MigrationError(
                        f"Table {name} contains an invalid row version."
                    )
            if version == SCHEMA_VERSION:
                connection.commit()
                return {
                    "created": False,
                    "migrated": False,
                    "backup": None,
                    "version": version,
                }
            backup = _backup(database, Path(backup_dir).resolve())
            for name in VERSION_TABLES:
                if "version" not in columns[name]:
                    connection.exec_driver_sql(
                        f'ALTER TABLE "{name}" ADD COLUMN version INTEGER NOT NULL DEFAULT 1 CHECK(version >= 1)'
                    )
            if "fingerprint" not in columns["inbound_messages"]:
                connection.exec_driver_sql(
                    'ALTER TABLE "inbound_messages" ADD COLUMN fingerprint TEXT'
                )
            connection.exec_driver_sql(f"PRAGMA user_version={SCHEMA_VERSION}")
            connection.commit()
            return {
                "created": False,
                "migrated": True,
                "backup": str(backup),
                "version": SCHEMA_VERSION,
            }
        except Exception:
            connection.rollback()
            raise
