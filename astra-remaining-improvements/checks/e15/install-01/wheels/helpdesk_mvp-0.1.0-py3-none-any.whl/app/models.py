from __future__ import annotations

from enum import Enum

from sqlalchemy import (
    JSON,
    Boolean,
    DateTime,
    Enum as SqlEnum,
    ForeignKey,
    Integer,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.orm import Mapped, declared_attr, mapped_column, relationship

from app.db import Base, utcnow


class Versioned:
    version: Mapped[int] = mapped_column(
        Integer, default=1, server_default="1", nullable=False
    )

    @declared_attr.directive
    def __mapper_args__(cls):
        return {"version_id_col": cls.version}


class Role(str, Enum):
    INSTANCE_ADMIN = "instance_admin"
    SUPPORT_MANAGER = "support_manager"
    AGENT = "agent"
    LIGHT_AGENT = "light_agent"
    CUSTOMER = "customer"
    INTEGRATION_BOT = "integration_bot"


class TicketStatus(str, Enum):
    NEW = "new"
    OPEN = "open"
    PENDING = "pending"
    ON_HOLD = "on_hold"
    RESOLVED = "resolved"
    CLOSED = "closed"
    SPAM = "spam"


class TicketPriority(str, Enum):
    LOW = "low"
    NORMAL = "normal"
    HIGH = "high"
    URGENT = "urgent"


class ChannelType(str, Enum):
    EMAIL = "email"
    WEB = "web"
    API = "api"
    CHAT = "chat"


class MessageKind(str, Enum):
    PUBLIC = "public_reply"
    INTERNAL = "internal_note"
    SYSTEM = "system"


class AutomationEvent(str, Enum):
    ON_CREATE = "on_create"
    ON_UPDATE = "on_update"
    ON_REPLY = "on_reply"
    ON_TIME_ELAPSED = "on_time_elapsed"


class Organization(Base):
    __tablename__ = "organizations"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(255), unique=True, nullable=False)
    created_at: Mapped[DateTime] = mapped_column(
        DateTime(timezone=True), default=utcnow, nullable=False
    )


class BusinessHours(Versioned, Base):
    __tablename__ = "business_hours"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(255), unique=True, nullable=False)
    timezone: Mapped[str] = mapped_column(String(64), default="UTC", nullable=False)
    schedule_json: Mapped[dict] = mapped_column(JSON, default=dict, nullable=False)
    created_at: Mapped[DateTime] = mapped_column(
        DateTime(timezone=True), default=utcnow, nullable=False
    )


class Team(Versioned, Base):
    __tablename__ = "teams"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(255), unique=True, nullable=False)
    description: Mapped[str | None] = mapped_column(Text, default=None)
    business_hours_id: Mapped[int | None] = mapped_column(
        ForeignKey("business_hours.id")
    )
    created_at: Mapped[DateTime] = mapped_column(
        DateTime(timezone=True), default=utcnow, nullable=False
    )

    business_hours: Mapped[BusinessHours | None] = relationship()
    members: Mapped[list["TeamMember"]] = relationship(
        back_populates="team", cascade="all, delete-orphan"
    )


class Customer(Versioned, Base):
    __tablename__ = "customers"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    email: Mapped[str] = mapped_column(String(255), nullable=False, unique=True)
    phone: Mapped[str | None] = mapped_column(String(64), default=None)
    company: Mapped[str | None] = mapped_column(String(255), default=None)
    organization_id: Mapped[int | None] = mapped_column(ForeignKey("organizations.id"))
    notes: Mapped[str | None] = mapped_column(Text, default=None)
    created_at: Mapped[DateTime] = mapped_column(
        DateTime(timezone=True), default=utcnow, nullable=False
    )

    organization: Mapped[Organization | None] = relationship()
    tickets: Mapped[list["Ticket"]] = relationship(back_populates="requester")


class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    full_name: Mapped[str] = mapped_column(String(255), nullable=False)
    email: Mapped[str] = mapped_column(String(255), nullable=False, unique=True)
    password_hash: Mapped[str] = mapped_column(String(255), nullable=False)
    role: Mapped[Role] = mapped_column(SqlEnum(Role), nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    customer_id: Mapped[int | None] = mapped_column(ForeignKey("customers.id"))
    preferences_json: Mapped[dict] = mapped_column(JSON, default=dict, nullable=False)
    created_at: Mapped[DateTime] = mapped_column(
        DateTime(timezone=True), default=utcnow, nullable=False
    )

    customer: Mapped[Customer | None] = relationship()
    teams: Mapped[list["TeamMember"]] = relationship(
        back_populates="user", cascade="all, delete-orphan"
    )


class TeamMember(Base):
    __tablename__ = "team_members"
    __table_args__ = (UniqueConstraint("team_id", "user_id", name="uq_team_member"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    team_id: Mapped[int] = mapped_column(ForeignKey("teams.id"), nullable=False)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), nullable=False)
    created_at: Mapped[DateTime] = mapped_column(
        DateTime(timezone=True), default=utcnow, nullable=False
    )

    team: Mapped[Team] = relationship(back_populates="members")
    user: Mapped[User] = relationship(back_populates="teams")


class Channel(Versioned, Base):
    __tablename__ = "channels"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(255), unique=True, nullable=False)
    type: Mapped[ChannelType] = mapped_column(SqlEnum(ChannelType), nullable=False)
    address: Mapped[str | None] = mapped_column(String(255), default=None)
    signature: Mapped[str | None] = mapped_column(Text, default=None)
    routing_team_id: Mapped[int | None] = mapped_column(ForeignKey("teams.id"))
    config_json: Mapped[dict] = mapped_column(JSON, default=dict, nullable=False)
    created_at: Mapped[DateTime] = mapped_column(
        DateTime(timezone=True), default=utcnow, nullable=False
    )

    routing_team: Mapped[Team | None] = relationship()


class SLA(Versioned, Base):
    __tablename__ = "slas"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(255), unique=True, nullable=False)
    first_response_minutes: Mapped[int] = mapped_column(
        Integer, default=60, nullable=False
    )
    next_response_minutes: Mapped[int] = mapped_column(
        Integer, default=240, nullable=False
    )
    resolution_minutes: Mapped[int] = mapped_column(
        Integer, default=480, nullable=False
    )
    business_hours_id: Mapped[int | None] = mapped_column(
        ForeignKey("business_hours.id")
    )
    pause_on_pending: Mapped[bool] = mapped_column(
        Boolean, default=True, nullable=False
    )
    pause_on_hold: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    is_default: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    created_at: Mapped[DateTime] = mapped_column(
        DateTime(timezone=True), default=utcnow, nullable=False
    )

    business_hours: Mapped[BusinessHours | None] = relationship()


class Ticket(Versioned, Base):
    __tablename__ = "tickets"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    number: Mapped[int] = mapped_column(Integer, unique=True, nullable=False)
    subject: Mapped[str] = mapped_column(String(255), nullable=False)
    type: Mapped[str | None] = mapped_column(String(64), default=None)
    requester_id: Mapped[int] = mapped_column(
        ForeignKey("customers.id"), nullable=False
    )
    status: Mapped[TicketStatus] = mapped_column(
        SqlEnum(TicketStatus), default=TicketStatus.NEW, nullable=False
    )
    priority: Mapped[TicketPriority] = mapped_column(
        SqlEnum(TicketPriority), default=TicketPriority.NORMAL, nullable=False
    )
    team_id: Mapped[int | None] = mapped_column(ForeignKey("teams.id"))
    assignee_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    channel_id: Mapped[int | None] = mapped_column(ForeignKey("channels.id"))
    sla_id: Mapped[int | None] = mapped_column(ForeignKey("slas.id"))
    merged_into_id: Mapped[int | None] = mapped_column(ForeignKey("tickets.id"))
    custom_fields_json: Mapped[dict] = mapped_column(JSON, default=dict, nullable=False)
    metadata_json: Mapped[dict] = mapped_column(JSON, default=dict, nullable=False)
    archived: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    deleted: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    first_response_due_at: Mapped[DateTime | None] = mapped_column(
        DateTime(timezone=True)
    )
    next_response_due_at: Mapped[DateTime | None] = mapped_column(
        DateTime(timezone=True)
    )
    resolution_due_at: Mapped[DateTime | None] = mapped_column(DateTime(timezone=True))
    first_responded_at: Mapped[DateTime | None] = mapped_column(DateTime(timezone=True))
    resolved_at: Mapped[DateTime | None] = mapped_column(DateTime(timezone=True))
    closed_at: Mapped[DateTime | None] = mapped_column(DateTime(timezone=True))
    last_customer_message_at: Mapped[DateTime | None] = mapped_column(
        DateTime(timezone=True)
    )
    last_agent_reply_at: Mapped[DateTime | None] = mapped_column(
        DateTime(timezone=True)
    )
    created_at: Mapped[DateTime] = mapped_column(
        DateTime(timezone=True), default=utcnow, nullable=False
    )
    updated_at: Mapped[DateTime] = mapped_column(
        DateTime(timezone=True), default=utcnow, onupdate=utcnow, nullable=False
    )

    requester: Mapped[Customer] = relationship(back_populates="tickets")
    team: Mapped[Team | None] = relationship()
    assignee: Mapped[User | None] = relationship(foreign_keys=[assignee_id])
    channel: Mapped[Channel | None] = relationship()
    sla: Mapped[SLA | None] = relationship()
    merged_into: Mapped[Ticket | None] = relationship(remote_side=[id])
    messages: Mapped[list["TicketMessage"]] = relationship(
        back_populates="ticket", cascade="all, delete-orphan"
    )
    events: Mapped[list["TicketEvent"]] = relationship(
        back_populates="ticket", cascade="all, delete-orphan"
    )
    followers: Mapped[list["TicketFollower"]] = relationship(
        back_populates="ticket", cascade="all, delete-orphan"
    )
    tag_links: Mapped[list["TicketTagLink"]] = relationship(
        back_populates="ticket", cascade="all, delete-orphan"
    )


class TicketMessage(Base):
    __tablename__ = "ticket_messages"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    ticket_id: Mapped[int] = mapped_column(ForeignKey("tickets.id"), nullable=False)
    author_user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    author_customer_id: Mapped[int | None] = mapped_column(ForeignKey("customers.id"))
    kind: Mapped[MessageKind] = mapped_column(SqlEnum(MessageKind), nullable=False)
    body: Mapped[str] = mapped_column(Text, nullable=False)
    metadata_json: Mapped[dict] = mapped_column(JSON, default=dict, nullable=False)
    created_at: Mapped[DateTime] = mapped_column(
        DateTime(timezone=True), default=utcnow, nullable=False
    )

    ticket: Mapped[Ticket] = relationship(back_populates="messages")
    author_user: Mapped[User | None] = relationship(foreign_keys=[author_user_id])
    author_customer: Mapped[Customer | None] = relationship(
        foreign_keys=[author_customer_id]
    )
    attachments: Mapped[list["Attachment"]] = relationship(
        back_populates="message", cascade="all, delete-orphan"
    )


class TicketEvent(Base):
    __tablename__ = "ticket_events"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    ticket_id: Mapped[int] = mapped_column(ForeignKey("tickets.id"), nullable=False)
    actor_user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    type: Mapped[str] = mapped_column(String(64), nullable=False)
    payload_json: Mapped[dict] = mapped_column(JSON, default=dict, nullable=False)
    created_at: Mapped[DateTime] = mapped_column(
        DateTime(timezone=True), default=utcnow, nullable=False
    )

    ticket: Mapped[Ticket] = relationship(back_populates="events")
    actor_user: Mapped[User | None] = relationship()


class TicketTag(Base):
    __tablename__ = "ticket_tags"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(64), unique=True, nullable=False)


class TicketTagLink(Base):
    __tablename__ = "ticket_tag_links"
    __table_args__ = (
        UniqueConstraint("ticket_id", "tag_id", name="uq_ticket_tag_link"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    ticket_id: Mapped[int] = mapped_column(ForeignKey("tickets.id"), nullable=False)
    tag_id: Mapped[int] = mapped_column(ForeignKey("ticket_tags.id"), nullable=False)

    ticket: Mapped[Ticket] = relationship(back_populates="tag_links")
    tag: Mapped[TicketTag] = relationship()


class TicketFollower(Base):
    __tablename__ = "ticket_followers"
    __table_args__ = (
        UniqueConstraint("ticket_id", "user_id", name="uq_ticket_follower"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    ticket_id: Mapped[int] = mapped_column(ForeignKey("tickets.id"), nullable=False)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), nullable=False)
    created_at: Mapped[DateTime] = mapped_column(
        DateTime(timezone=True), default=utcnow, nullable=False
    )

    ticket: Mapped[Ticket] = relationship(back_populates="followers")
    user: Mapped[User] = relationship()


class Attachment(Base):
    __tablename__ = "attachments"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    ticket_id: Mapped[int] = mapped_column(ForeignKey("tickets.id"), nullable=False)
    message_id: Mapped[int | None] = mapped_column(ForeignKey("ticket_messages.id"))
    filename: Mapped[str] = mapped_column(String(255), nullable=False)
    content_type: Mapped[str] = mapped_column(String(255), nullable=False)
    size: Mapped[int] = mapped_column(Integer, nullable=False)
    storage_path: Mapped[str] = mapped_column(String(500), nullable=False)
    created_at: Mapped[DateTime] = mapped_column(
        DateTime(timezone=True), default=utcnow, nullable=False
    )

    message: Mapped[TicketMessage | None] = relationship(back_populates="attachments")


class AutomationRule(Versioned, Base):
    __tablename__ = "automation_rules"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(255), unique=True, nullable=False)
    event: Mapped[AutomationEvent] = mapped_column(
        SqlEnum(AutomationEvent), nullable=False
    )
    enabled: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    position: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    conditions_json: Mapped[dict] = mapped_column(JSON, default=dict, nullable=False)
    actions_json: Mapped[dict] = mapped_column(JSON, default=dict, nullable=False)
    created_at: Mapped[DateTime] = mapped_column(
        DateTime(timezone=True), default=utcnow, nullable=False
    )


class AutomationRun(Base):
    __tablename__ = "automation_runs"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    rule_id: Mapped[int] = mapped_column(
        ForeignKey("automation_rules.id"), nullable=False
    )
    ticket_id: Mapped[int] = mapped_column(ForeignKey("tickets.id"), nullable=False)
    status: Mapped[str] = mapped_column(String(32), default="success", nullable=False)
    details_json: Mapped[dict] = mapped_column(JSON, default=dict, nullable=False)
    created_at: Mapped[DateTime] = mapped_column(
        DateTime(timezone=True), default=utcnow, nullable=False
    )

    rule: Mapped[AutomationRule] = relationship()
    ticket: Mapped[Ticket] = relationship()


class Macro(Base):
    __tablename__ = "macros"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(255), unique=True, nullable=False)
    description: Mapped[str | None] = mapped_column(Text, default=None)
    actions_json: Mapped[dict] = mapped_column(JSON, default=dict, nullable=False)
    created_at: Mapped[DateTime] = mapped_column(
        DateTime(timezone=True), default=utcnow, nullable=False
    )


class CannedReply(Versioned, Base):
    __tablename__ = "canned_replies"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    title: Mapped[str] = mapped_column(String(255), unique=True, nullable=False)
    body_template: Mapped[str] = mapped_column(Text, nullable=False)
    created_at: Mapped[DateTime] = mapped_column(
        DateTime(timezone=True), default=utcnow, nullable=False
    )


class Report(Base):
    __tablename__ = "reports"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(255), unique=True, nullable=False)
    definition_json: Mapped[dict] = mapped_column(JSON, default=dict, nullable=False)
    created_at: Mapped[DateTime] = mapped_column(
        DateTime(timezone=True), default=utcnow, nullable=False
    )


class Webhook(Base):
    __tablename__ = "webhooks"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(255), unique=True, nullable=False)
    target_url: Mapped[str] = mapped_column(String(500), nullable=False)
    secret_hash: Mapped[str] = mapped_column(String(255), nullable=False)
    event_types_json: Mapped[list] = mapped_column(JSON, default=list, nullable=False)
    enabled: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    created_at: Mapped[DateTime] = mapped_column(
        DateTime(timezone=True), default=utcnow, nullable=False
    )


class AuditLog(Base):
    __tablename__ = "audit_logs"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    actor_user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    actor_customer_id: Mapped[int | None] = mapped_column(ForeignKey("customers.id"))
    entity_type: Mapped[str] = mapped_column(String(64), nullable=False)
    entity_id: Mapped[str] = mapped_column(String(64), nullable=False)
    action: Mapped[str] = mapped_column(String(64), nullable=False)
    details_json: Mapped[dict] = mapped_column(JSON, default=dict, nullable=False)
    request_id: Mapped[str | None] = mapped_column(String(64), default=None)
    created_at: Mapped[DateTime] = mapped_column(
        DateTime(timezone=True), default=utcnow, nullable=False
    )

    actor_user: Mapped[User | None] = relationship(foreign_keys=[actor_user_id])
    actor_customer: Mapped[Customer | None] = relationship(
        foreign_keys=[actor_customer_id]
    )


class Session(Base):
    __tablename__ = "sessions"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), nullable=False)
    token_hash: Mapped[str] = mapped_column(String(255), unique=True, nullable=False)
    created_at: Mapped[DateTime] = mapped_column(
        DateTime(timezone=True), default=utcnow, nullable=False
    )
    expires_at: Mapped[DateTime] = mapped_column(
        DateTime(timezone=True), nullable=False
    )
    last_seen_at: Mapped[DateTime] = mapped_column(
        DateTime(timezone=True), default=utcnow, nullable=False
    )
    user_agent: Mapped[str | None] = mapped_column(String(500), default=None)
    ip_address: Mapped[str | None] = mapped_column(String(128), default=None)

    user: Mapped[User] = relationship()


class ApiToken(Base):
    __tablename__ = "api_tokens"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), nullable=False)
    label: Mapped[str] = mapped_column(String(255), nullable=False)
    token_hash: Mapped[str] = mapped_column(String(255), unique=True, nullable=False)
    created_at: Mapped[DateTime] = mapped_column(
        DateTime(timezone=True), default=utcnow, nullable=False
    )
    last_used_at: Mapped[DateTime | None] = mapped_column(DateTime(timezone=True))
    expires_at: Mapped[DateTime | None] = mapped_column(DateTime(timezone=True))

    user: Mapped[User] = relationship()


class InboundMessage(Base):
    __tablename__ = "inbound_messages"
    __table_args__ = (
        UniqueConstraint("source", "external_id", name="uq_inbound_message"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    source: Mapped[str] = mapped_column(String(32), nullable=False)
    external_id: Mapped[str] = mapped_column(String(255), nullable=False)
    fingerprint: Mapped[str | None] = mapped_column(String(64), nullable=True)
    ticket_id: Mapped[int | None] = mapped_column(ForeignKey("tickets.id"))
    channel_id: Mapped[int | None] = mapped_column(ForeignKey("channels.id"))
    created_at: Mapped[DateTime] = mapped_column(
        DateTime(timezone=True), default=utcnow, nullable=False
    )

    ticket: Mapped[Ticket | None] = relationship()
    channel: Mapped[Channel | None] = relationship()
