from __future__ import annotations

from fastapi import HTTPException, status

from app.models import Role, User


STAFF_ROLES = {
    Role.INSTANCE_ADMIN,
    Role.SUPPORT_MANAGER,
    Role.AGENT,
    Role.LIGHT_AGENT,
}


def require_roles(user: User, *roles: Role) -> None:
    if user.role not in roles:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN, detail="Insufficient permissions"
        )


def require_staff(user: User) -> None:
    if user.role not in STAFF_ROLES:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN, detail="Staff access required"
        )


def can_reply_externally(user: User) -> bool:
    return user.role in {Role.INSTANCE_ADMIN, Role.SUPPORT_MANAGER, Role.AGENT}
