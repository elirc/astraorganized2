"""Idempotent creation receipts, stored in the same transaction as a ticket."""

import hashlib
import json
import uuid

from fastapi import HTTPException
from sqlalchemy import select

from app.models import InboundMessage, Ticket


def operation_key(request):
    value = request.headers.get("idempotency-key", "")
    try:
        parsed = uuid.UUID(value)
        if parsed.version != 4 or str(parsed) != value.lower():
            raise ValueError()
    except (ValueError, AttributeError):
        raise HTTPException(
            status_code=428,
            detail="Send an Idempotency-Key UUID4 for this creation. Keep the same key when retrying the same draft.",
        )
    return str(parsed)


def fingerprint(payload):
    raw = json.dumps(
        payload,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
        allow_nan=False,
    )
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def find_receipt(db, source, key, payload):
    receipt = db.scalar(
        select(InboundMessage).where(
            InboundMessage.source == source, InboundMessage.external_id == key
        )
    )
    if receipt is None:
        return None
    if receipt.fingerprint is None:
        raise HTTPException(
            status_code=409,
            detail="This legacy receipt has no payload fingerprint. Review its existing ticket instead of replaying an unverifiable request.",
        )
    if receipt.fingerprint != fingerprint(payload):
        raise HTTPException(
            status_code=409,
            detail="This operation key already belongs to different content. The earlier ticket was preserved; review it before creating a separate operation.",
        )
    ticket = db.get(Ticket, receipt.ticket_id)
    if ticket is None:
        raise HTTPException(
            status_code=409,
            detail="The receipt refers to a missing ticket. Preserve the receipt and review storage consistency.",
        )
    return ticket


def record_receipt(db, source, key, payload, ticket):
    db.add(
        InboundMessage(
            source=source,
            external_id=key,
            fingerprint=fingerprint(payload),
            ticket_id=ticket.id,
            channel_id=ticket.channel_id,
        )
    )
    db.flush()


def intake_receipt(ticket):
    return {
        "id": ticket.id,
        "number": ticket.number,
        "status": ticket.status.value,
        "receipt": "Submitted for staff review. Providing an email address does not verify identity.",
    }
