"""Resolve relationships before mutations; SQL foreign keys remain the final guard."""

from fastapi import HTTPException
from sqlalchemy import select

from app.models import Team, TeamMember, User, Role

FULL_STAFF = {Role.INSTANCE_ADMIN, Role.SUPPORT_MANAGER, Role.AGENT}


def referenced(db, model, identifier, label):
    if identifier is None:
        return None
    item = db.get(model, identifier)
    if item is None:
        raise HTTPException(status_code=422, detail=f"{label} does not exist.")
    return item


def assignment(db, team_id, assignee_id, actor=None):
    team = referenced(db, Team, team_id, "Team")
    agent = referenced(db, User, assignee_id, "Assignee")
    if (
        actor
        and actor.role == Role.AGENT
        and team
        and team.id not in {m.team_id for m in actor.teams}
    ):
        raise HTTPException(
            status_code=403,
            detail="Agents may assign work only within their teams or the unassigned queue.",
        )
    if agent:
        if not agent.is_active or agent.role not in FULL_STAFF:
            raise HTTPException(
                status_code=422, detail="Assignee must be an active full staff member."
            )
        if (
            team
            and agent.role == Role.AGENT
            and not db.scalar(
                select(TeamMember.id).where(
                    TeamMember.team_id == team.id, TeamMember.user_id == agent.id
                )
            )
        ):
            raise HTTPException(
                status_code=422,
                detail="The assigned agent must belong to the selected team.",
            )
    return team, agent
