from __future__ import annotations

import base64
import binascii
import hashlib
import hmac
import os
import secrets
from datetime import timedelta

from app.config import SESSION_TTL_DAYS
from app.db import utcnow


def hash_password(password: str, salt: bytes | None = None) -> str:
    salt = salt or os.urandom(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, 390000)
    return base64.b64encode(salt + digest).decode("ascii")


def verify_password(password: str, stored_hash: str) -> bool:
    if not isinstance(password, str) or not isinstance(stored_hash, str):
        return False
    try:
        encoded_password = password.encode("utf-8")
        if len(encoded_password) > 1024 or len(stored_hash) != 64:
            return False
        decoded = base64.b64decode(stored_hash.encode("ascii"), validate=True)
    except (UnicodeError, ValueError, binascii.Error):
        return False
    if len(decoded) != 48:
        return False
    salt, digest = decoded[:16], decoded[16:]
    candidate = hashlib.pbkdf2_hmac("sha256", encoded_password, salt, 390000)
    return hmac.compare_digest(digest, candidate)


def new_token() -> str:
    return secrets.token_urlsafe(32)


def hash_token(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def session_expiry():
    return utcnow() + timedelta(days=SESSION_TTL_DAYS)
