from __future__ import annotations

import csv
import io
import re
import uuid
from datetime import datetime, time, timedelta, timezone
from pathlib import Path

from fastapi import HTTPException, UploadFile, status
from sqlalchemy import Select, and_, false, func, or_, select, true
from sqlalchemy.orm import Session, joinedload

from app.business_time import (
    DEFAULT_SCHEDULE,
    ensure_schedule,
    parse_hhmm,
    get_timezone,
    active_intervals_for_day,
    add_business_minutes,
    business_minutes_between,
)
from app.config import MAX_ATTACHMENT_SIZE, UPLOAD_DIR
from app.db import utcnow
from app.models import (
    ApiToken,
    Attachment,
    AuditLog,
    AutomationEvent,
    AutomationRule,
    AutomationRun,
    BusinessHours,
    CannedReply,
    Channel,
    ChannelType,
    Customer,
    InboundMessage,
    Macro,
    MessageKind,
    Organization,
    Report,
    Role,
    SLA,
    Team,
    TeamMember,
    Ticket,
    TicketEvent,
    TicketFollower,
    TicketMessage,
    TicketPriority,
    TicketStatus,
    TicketTag,
    TicketTagLink,
    User,
    Webhook,
)
from app.permissions import STAFF_ROLES, can_reply_externally
from app.security import hash_password, hash_token
from app import contracts
from app.references import assignment, referenced
from app.attachments import save_attachments as store_attachments


def team_ids_for_user(user: User) -> list[int]:
    return [membership.team_id for membership in user.teams]


def ticket_visibility_clause(user: User):
    if user.role in {Role.INSTANCE_ADMIN, Role.SUPPORT_MANAGER}:
        return true()
    if user.role == Role.CUSTOMER:
        return Ticket.requester_id == user.customer_id if user.customer_id else false()
    if user.role not in STAFF_ROLES:
        return false()
    return or_(
        Ticket.assignee_id == user.id,
        Ticket.team_id.is_(None),
        Ticket.team_id.in_(team_ids_for_user(user)),
        Ticket.followers.any(TicketFollower.user_id == user.id),
    )


def staff_ticket_query(user: User) -> Select[tuple[Ticket]]:
    stmt = (
        select(Ticket)
        .options(
            joinedload(Ticket.requester),
            joinedload(Ticket.assignee),
            joinedload(Ticket.team),
            joinedload(Ticket.channel),
            joinedload(Ticket.sla).joinedload(SLA.business_hours),
            joinedload(Ticket.tag_links).joinedload(TicketTagLink.tag),
            joinedload(Ticket.followers).joinedload(TicketFollower.user),
        )
        .where(Ticket.deleted.is_(False))
        .order_by(Ticket.updated_at.desc(), Ticket.id.desc())
    )
    return stmt.where(ticket_visibility_clause(user))


def ticket_is_visible_to_user(ticket: Ticket, user: User) -> bool:
    if ticket.deleted:
        return False
    if user.role in {Role.INSTANCE_ADMIN, Role.SUPPORT_MANAGER}:
        return True
    if user.role == Role.CUSTOMER:
        return bool(user.customer_id and ticket.requester_id == user.customer_id)
    if user.role in STAFF_ROLES:
        if ticket.assignee_id == user.id:
            return True
        if any(follower.user_id == user.id for follower in ticket.followers):
            return True
        teams = team_ids_for_user(user)
        return ticket.team_id is None or ticket.team_id in teams
    return False


def require_ticket_access(ticket: Ticket, user: User) -> None:
    if not ticket_is_visible_to_user(ticket, user):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN, detail="Ticket access denied"
        )


def require_writable_ticket(ticket: Ticket) -> None:
    if ticket.deleted or ticket.merged_into_id is not None or ticket.archived:
        raise HTTPException(
            status_code=409,
            detail="This ticket is archived, deleted or merged and is read-only.",
        )


def default_business_hours(db: Session) -> BusinessHours:
    item = db.scalar(
        select(BusinessHours).where(BusinessHours.name == "Default Business Hours")
    )
    if item:
        return item
    item = BusinessHours(
        name="Default Business Hours",
        timezone="America/Los_Angeles",
        schedule_json=DEFAULT_SCHEDULE,
    )
    db.add(item)
    db.flush()
    return item


def default_sla(db: Session) -> SLA:
    item = db.scalar(select(SLA).where(SLA.is_default.is_(True)))
    if item:
        return item
    bh = default_business_hours(db)
    item = SLA(
        name="Default SLA",
        first_response_minutes=60,
        next_response_minutes=240,
        resolution_minutes=480,
        business_hours_id=bh.id,
        pause_on_pending=True,
        pause_on_hold=True,
        is_default=True,
    )
    db.add(item)
    db.flush()
    return item


def team_business_hours(ticket: Ticket, db: Session) -> BusinessHours:
    if ticket.sla and ticket.sla.business_hours:
        return ticket.sla.business_hours
    if ticket.team and ticket.team.business_hours:
        return ticket.team.business_hours
    return default_business_hours(db)


def sla_paused_for_status(ticket: Ticket, sla: SLA | None) -> bool:
    if not sla:
        return False
    if ticket.status == TicketStatus.PENDING and sla.pause_on_pending:
        return True
    if ticket.status == TicketStatus.ON_HOLD and sla.pause_on_hold:
        return True
    return False


def pause_sla(ticket: Ticket, business_hours: BusinessHours) -> None:
    now = utcnow()
    metadata = dict(ticket.metadata_json or {})
    pause_meta: dict[str, int | None] = {}
    if ticket.first_response_due_at:
        pause_meta["first_response_minutes"] = business_minutes_between(
            now, ticket.first_response_due_at, business_hours
        )
        ticket.first_response_due_at = None
    if ticket.next_response_due_at:
        pause_meta["next_response_minutes"] = business_minutes_between(
            now, ticket.next_response_due_at, business_hours
        )
        ticket.next_response_due_at = None
    if ticket.resolution_due_at:
        pause_meta["resolution_minutes"] = business_minutes_between(
            now, ticket.resolution_due_at, business_hours
        )
        ticket.resolution_due_at = None
    metadata["sla_pause"] = pause_meta
    ticket.metadata_json = metadata


def resume_sla(ticket: Ticket, business_hours: BusinessHours) -> None:
    now = utcnow()
    metadata = dict(ticket.metadata_json or {})
    pause_meta = metadata.pop("sla_pause", None)
    if not pause_meta:
        ticket.metadata_json = metadata
        return
    if (
        pause_meta.get("first_response_minutes") is not None
        and ticket.first_responded_at is None
    ):
        ticket.first_response_due_at = add_business_minutes(
            now, pause_meta["first_response_minutes"], business_hours
        )
    if pause_meta.get("next_response_minutes") is not None:
        ticket.next_response_due_at = add_business_minutes(
            now, pause_meta["next_response_minutes"], business_hours
        )
    if pause_meta.get("resolution_minutes") is not None and ticket.status not in {
        TicketStatus.RESOLVED,
        TicketStatus.CLOSED,
        TicketStatus.SPAM,
    }:
        ticket.resolution_due_at = add_business_minutes(
            now, pause_meta["resolution_minutes"], business_hours
        )
    ticket.metadata_json = metadata


def refresh_sla(ticket: Ticket, db: Session) -> None:
    if (
        ticket.deleted
        or ticket.archived
        or ticket.status
        in {TicketStatus.RESOLVED, TicketStatus.CLOSED, TicketStatus.SPAM}
    ):
        ticket.first_response_due_at = None
        ticket.next_response_due_at = None
        ticket.resolution_due_at = None
        return
    sla = ticket.sla or default_sla(db)
    business_hours = team_business_hours(ticket, db)
    origin = ticket.created_at
    if (ticket.metadata_json or {}).get("sla_reopened_at"):
        origin = datetime.fromisoformat(ticket.metadata_json["sla_reopened_at"])
    if sla_paused_for_status(ticket, sla):
        if "sla_pause" not in (ticket.metadata_json or {}):
            pause_sla(ticket, business_hours)
        return
    if "sla_pause" in (ticket.metadata_json or {}):
        resume_sla(ticket, business_hours)
        return
    if ticket.first_responded_at is None and ticket.first_response_due_at is None:
        ticket.first_response_due_at = add_business_minutes(
            origin, sla.first_response_minutes, business_hours
        )
    if (
        ticket.status
        not in {TicketStatus.RESOLVED, TicketStatus.CLOSED, TicketStatus.SPAM}
        and ticket.resolution_due_at is None
    ):
        ticket.resolution_due_at = add_business_minutes(
            origin, sla.resolution_minutes, business_hours
        )


def next_ticket_number(db: Session) -> int:
    current = db.scalar(select(func.max(Ticket.number)))
    return (current or 999) + 1


def audit(
    db: Session,
    *,
    entity_type: str,
    entity_id: str,
    action: str,
    details: dict | None = None,
    actor_user: User | None = None,
    actor_customer: Customer | None = None,
    request_id: str | None = None,
) -> None:
    db.add(
        AuditLog(
            actor_user_id=actor_user.id if actor_user else None,
            actor_customer_id=actor_customer.id if actor_customer else None,
            entity_type=entity_type,
            entity_id=entity_id,
            action=action,
            details_json=details or {},
            request_id=request_id,
        )
    )


def add_event(
    db: Session,
    ticket: Ticket,
    event_type: str,
    payload: dict,
    actor_user: User | None = None,
) -> None:
    db.add(
        TicketEvent(
            ticket_id=ticket.id,
            actor_user_id=actor_user.id if actor_user else None,
            type=event_type,
            payload_json=payload,
        )
    )


def get_or_create_tag(db: Session, name: str) -> TicketTag:
    normalized = name.strip().lower()
    tag = db.scalar(select(TicketTag).where(TicketTag.name == normalized))
    if tag:
        return tag
    tag = TicketTag(name=normalized)
    db.add(tag)
    db.flush()
    return tag


def sync_ticket_tags(db: Session, ticket: Ticket, tag_names: list[str]) -> None:
    normalized = {tag.strip().lower() for tag in tag_names if tag.strip()}
    existing = {link.tag.name: link for link in ticket.tag_links}
    for name in normalized - existing.keys():
        ticket.tag_links.append(TicketTagLink(tag=get_or_create_tag(db, name)))
    for name in existing.keys() - normalized:
        db.delete(existing[name])


def render_template_text(template: str, ticket: Ticket) -> str:
    return (
        template.replace("{{ customer_name }}", ticket.requester.name)
        .replace("{{ ticket_number }}", str(ticket.number))
        .replace("{{ ticket_subject }}", ticket.subject)
    )


def as_utc(value: datetime | None) -> datetime | None:
    if value is None:
        return None
    if value.tzinfo is None:
        return value.replace(tzinfo=timezone.utc)
    return value.astimezone(timezone.utc)


def transition_status(ticket, new_status):
    """Terminal states stop timers; reopening starts a new resolution window."""
    previous = ticket.status
    if previous == new_status:
        return
    ticket.status = new_status
    now = utcnow()
    terminal = {TicketStatus.RESOLVED, TicketStatus.CLOSED, TicketStatus.SPAM}
    if new_status == TicketStatus.RESOLVED:
        ticket.resolved_at = now
        ticket.closed_at = None
    elif new_status == TicketStatus.CLOSED:
        ticket.closed_at = now
        if ticket.resolved_at is None:
            ticket.resolved_at = now
    elif new_status not in terminal:
        ticket.resolved_at = None
        ticket.closed_at = None
        if previous in terminal:
            metadata = dict(ticket.metadata_json or {})
            metadata["sla_reopened_at"] = now.isoformat()
            ticket.metadata_json = metadata
    if new_status in terminal:
        ticket.first_response_due_at = None
        ticket.next_response_due_at = None
        ticket.resolution_due_at = None
        metadata = dict(ticket.metadata_json or {})
        metadata.pop("sla_pause", None)
        ticket.metadata_json = metadata
    ticket.updated_at = now


def public_reply_state(db, ticket, at, actor_user=None, actor_customer=None):
    if actor_customer:
        ticket.last_customer_message_at = at
        if ticket.status in {
            TicketStatus.PENDING,
            TicketStatus.RESOLVED,
            TicketStatus.CLOSED,
            TicketStatus.SPAM,
        }:
            transition_status(ticket, TicketStatus.OPEN)
        refresh_sla(ticket, db)
        if ticket.first_responded_at:
            sla = ticket.sla or default_sla(db)
            ticket.next_response_due_at = add_business_minutes(
                at, sla.next_response_minutes, team_business_hours(ticket, db)
            )
    elif actor_user:
        ticket.last_agent_reply_at = at
        if ticket.first_responded_at is None:
            ticket.first_responded_at = at
        if ticket.status in {
            TicketStatus.NEW,
            TicketStatus.PENDING,
            TicketStatus.RESOLVED,
            TicketStatus.CLOSED,
            TicketStatus.SPAM,
        }:
            transition_status(ticket, TicketStatus.OPEN)
        refresh_sla(ticket, db)
        ticket.first_response_due_at = None
        ticket.next_response_due_at = None
    ticket.updated_at = at


async def add_message(
    db: Session,
    ticket: Ticket,
    *,
    body: str,
    kind: MessageKind,
    actor_user: User | None = None,
    actor_customer: Customer | None = None,
    files: list[UploadFile] | None = None,
    request_id: str | None = None,
    trigger_automations: bool = True,
) -> TicketMessage:
    require_writable_ticket(ticket)
    if (
        actor_user
        and kind == MessageKind.PUBLIC
        and not can_reply_externally(actor_user)
    ):
        raise HTTPException(
            status_code=403, detail="This role cannot send public replies."
        )
    if actor_customer and (
        actor_customer.id != ticket.requester_id or kind != MessageKind.PUBLIC
    ):
        raise HTTPException(
            status_code=403, detail="Customer conversation access denied."
        )
    if actor_user is None and actor_customer is None:
        raise HTTPException(
            status_code=403, detail="An authenticated message author is required."
        )
    body = contracts.validate({"body": body}, contracts.MessageBody)["body"]
    if not body.strip():
        raise HTTPException(status_code=400, detail="Message body is required")
    ticket.updated_at = utcnow()
    message = TicketMessage(
        ticket_id=ticket.id,
        author_user_id=actor_user.id if actor_user else None,
        author_customer_id=actor_customer.id if actor_customer else None,
        kind=kind,
        body=body.strip(),
        created_at=utcnow(),
    )
    ticket.messages.append(message)
    if files:
        await store_attachments(db, ticket, message, files, UPLOAD_DIR)
    if kind == MessageKind.PUBLIC:
        public_reply_state(db, ticket, message.created_at, actor_user, actor_customer)
    add_event(
        db,
        ticket,
        "message_added",
        {"kind": kind.value, "preview": body[:120]},
        actor_user=actor_user,
    )
    audit(
        db,
        entity_type="ticket",
        entity_id=str(ticket.id),
        action="message_added",
        details={"kind": kind.value},
        actor_user=actor_user,
        actor_customer=actor_customer,
        request_id=request_id,
    )
    refresh_sla(ticket, db)
    if trigger_automations:
        run_automations(
            db,
            AutomationEvent.ON_REPLY,
            ticket,
            actor_user=actor_user,
            context_text=body,
        )
    return message


def apply_ticket_updates(
    db: Session,
    ticket: Ticket,
    payload: dict,
    actor_user: User | None = None,
    request_id: str | None = None,
) -> Ticket:
    require_writable_ticket(ticket)
    if actor_user and not can_reply_externally(actor_user):
        raise HTTPException(
            status_code=403,
            detail="This role may add internal notes but cannot edit ticket fields.",
        )
    payload = contracts.validate(payload, contracts.TicketPatch, patch=True)
    selected_team = payload.get("team_id", ticket.team_id)
    selected_agent = payload.get("assignee_id", ticket.assignee_id)
    if "team_id" in payload or "assignee_id" in payload:
        assignment(db, selected_team, selected_agent, actor_user)
    changed: dict[str, object] = {}
    if "subject" in payload and payload["subject"]:
        changed["subject"] = {"from": ticket.subject, "to": payload["subject"]}
        ticket.subject = payload["subject"]
    if "status" in payload and payload["status"]:
        new_status = TicketStatus(payload["status"])
        if new_status != ticket.status:
            changed["status"] = {"from": ticket.status.value, "to": new_status.value}
            transition_status(ticket, new_status)
    if "priority" in payload and payload["priority"]:
        new_priority = TicketPriority(payload["priority"])
        if new_priority != ticket.priority:
            changed["priority"] = {
                "from": ticket.priority.value,
                "to": new_priority.value,
            }
            ticket.priority = new_priority
    if "team_id" in payload:
        team_id = payload["team_id"]
        if team_id != ticket.team_id:
            changed["team_id"] = {"from": ticket.team_id, "to": team_id}
            ticket.team_id = team_id
            ticket.team = db.get(Team, team_id) if team_id else None
    if "assignee_id" in payload:
        assignee_id = payload["assignee_id"]
        if assignee_id != ticket.assignee_id:
            changed["assignee_id"] = {"from": ticket.assignee_id, "to": assignee_id}
            ticket.assignee_id = assignee_id
            ticket.assignee = db.get(User, assignee_id) if assignee_id else None
    if "type" in payload:
        changed["type"] = {"from": ticket.type, "to": payload["type"]}
        ticket.type = payload["type"]
    if "custom_fields" in payload:
        ticket.custom_fields_json = payload["custom_fields"] or {}
        changed["custom_fields"] = {"to": ticket.custom_fields_json}
    if "tags" in payload:
        sync_ticket_tags(db, ticket, payload["tags"] or [])
        changed["tags"] = {"to": [link.tag.name for link in ticket.tag_links]}
    if changed:
        ticket.updated_at = utcnow()
        refresh_sla(ticket, db)
        add_event(db, ticket, "ticket_updated", changed, actor_user=actor_user)
        audit(
            db,
            entity_type="ticket",
            entity_id=str(ticket.id),
            action="ticket_updated",
            details=changed,
            actor_user=actor_user,
            request_id=request_id,
        )
        run_automations(db, AutomationEvent.ON_UPDATE, ticket, actor_user=actor_user)
    return ticket


def match_automation(
    rule: AutomationRule, ticket: Ticket, *, context_text: str = ""
) -> bool:
    conditions = rule.conditions_json or {}
    if statuses := conditions.get("status"):
        if ticket.status.value not in statuses:
            return False
    if priorities := conditions.get("priority"):
        if ticket.priority.value not in priorities:
            return False
    if channels := conditions.get("channel"):
        if not ticket.channel or ticket.channel.type.value not in channels:
            return False
    if team_ids := conditions.get("team_id"):
        if ticket.team_id not in team_ids:
            return False
    if text_match := conditions.get("text_match"):
        haystack = f"{ticket.subject}\n{context_text}".lower()
        if text_match.lower() not in haystack:
            return False
    if tag_names := conditions.get("tags"):
        current = {link.tag.name for link in ticket.tag_links}
        if not set(tag_names).issubset(current):
            return False
    if customer_ids := conditions.get("customer_id"):
        if ticket.requester_id not in customer_ids:
            return False
    return True


def run_automations(
    db: Session,
    event: AutomationEvent,
    ticket: Ticket,
    *,
    actor_user: User | None = None,
    context_text: str = "",
) -> None:
    rules = db.scalars(
        select(AutomationRule)
        .where(AutomationRule.enabled.is_(True), AutomationRule.event == event)
        .order_by(AutomationRule.position.asc(), AutomationRule.id.asc())
    ).all()
    for rule in rules:
        if not match_automation(rule, ticket, context_text=context_text):
            continue
        details: dict[str, object] = {}
        actions = contracts.validate(rule.actions_json or {}, contracts.Actions)
        if (
            actions.get("assign_team_id") is not None
            or actions.get("assign_agent_id") is not None
        ):
            assignment(
                db,
                actions.get("assign_team_id", ticket.team_id),
                actions.get("assign_agent_id", ticket.assignee_id),
            )
        if actions.get("set_priority"):
            ticket.priority = TicketPriority(actions["set_priority"])
            details["set_priority"] = actions["set_priority"]
        if actions.get("set_status"):
            transition_status(ticket, TicketStatus(actions["set_status"]))
            details["set_status"] = actions["set_status"]
        if actions.get("assign_team_id"):
            ticket.team_id = actions["assign_team_id"]
            ticket.team = db.get(Team, ticket.team_id)
            details["assign_team_id"] = actions["assign_team_id"]
        if actions.get("assign_agent_id"):
            ticket.assignee_id = actions["assign_agent_id"]
            ticket.assignee = db.get(User, ticket.assignee_id)
            details["assign_agent_id"] = actions["assign_agent_id"]
        if actions.get("add_tags"):
            current = [link.tag.name for link in ticket.tag_links]
            sync_ticket_tags(db, ticket, current + list(actions["add_tags"]))
            details["add_tags"] = actions["add_tags"]
        if actions.get("remove_tags"):
            remaining = [
                link.tag.name
                for link in ticket.tag_links
                if link.tag.name not in set(actions["remove_tags"])
            ]
            sync_ticket_tags(db, ticket, remaining)
            details["remove_tags"] = actions["remove_tags"]
        canned_reply_id = actions.get("send_canned_reply_id")
        if canned_reply_id and actor_user and can_reply_externally(actor_user):
            canned = db.get(CannedReply, canned_reply_id)
            if canned:
                db.add(
                    TicketMessage(
                        ticket=ticket,
                        author_user_id=actor_user.id,
                        kind=MessageKind.PUBLIC,
                        body=render_template_text(canned.body_template, ticket),
                    )
                )
                public_reply_state(db, ticket, utcnow(), actor_user=actor_user)
                details["send_canned_reply_id"] = canned_reply_id
        db.add(
            AutomationRun(
                rule_id=rule.id,
                ticket_id=ticket.id,
                status="success",
                details_json=details,
            )
        )
        if details:
            ticket.updated_at = utcnow()
            add_event(
                db,
                ticket,
                "automation_applied",
                {"rule": rule.name, **details},
                actor_user=actor_user,
            )
            audit(
                db,
                entity_type="ticket",
                entity_id=str(ticket.id),
                action="automation_applied",
                details={"rule": rule.name, **details},
                actor_user=actor_user,
            )
        refresh_sla(ticket, db)


def overdue_state(ticket: Ticket) -> bool:
    now = utcnow()
    return any(
        due_at is not None and as_utc(due_at) < now
        for due_at in [
            ticket.first_response_due_at,
            ticket.next_response_due_at,
            ticket.resolution_due_at,
        ]
    )


def serialize_message(message: TicketMessage, *, staff_view: bool = True) -> dict:
    author_name = "System"
    if (message.metadata_json or {}).get("identity_verified") is False:
        author_name = "Unverified intake"
    if message.author_user:
        author_name = message.author_user.full_name
    elif message.author_customer:
        author_name = message.author_customer.name
    result = {
        "id": message.id,
        "kind": message.kind.value,
        "body": message.body,
        "author_name": author_name,
        "author_user_id": message.author_user_id,
        "author_customer_id": message.author_customer_id,
        "created_at": as_utc(message.created_at).isoformat()
        if message.created_at
        else None,
        "attachments": [
            {
                "id": attachment.id,
                "filename": attachment.filename,
                "size": attachment.size,
                "content_type": attachment.content_type,
            }
            for attachment in message.attachments
        ],
    }
    if not staff_view:
        result.pop("author_user_id")
        result.pop("author_customer_id")
    return result


def serialize_ticket(
    ticket: Ticket, *, include_messages: bool = True, staff_view: bool = True
) -> dict:
    messages = ticket.messages if include_messages else []
    if not staff_view:
        messages = [
            message for message in messages if message.kind == MessageKind.PUBLIC
        ]
        return {
            "id": ticket.id,
            "version": ticket.version,
            "number": ticket.number,
            "subject": ticket.subject,
            "status": ticket.status.value,
            "priority": ticket.priority.value,
            "requester": {
                "name": ticket.requester.name,
                "email": ticket.requester.email,
            },
            "team": None,
            "created_at": as_utc(ticket.created_at).isoformat()
            if ticket.created_at
            else None,
            "updated_at": as_utc(ticket.updated_at).isoformat()
            if ticket.updated_at
            else None,
            "messages": [
                serialize_message(message, staff_view=False) for message in messages
            ],
        }
    return {
        "id": ticket.id,
        "version": ticket.version,
        "number": ticket.number,
        "subject": ticket.subject,
        "status": ticket.status.value,
        "priority": ticket.priority.value,
        "type": ticket.type,
        "archived": ticket.archived,
        "merged_into_id": ticket.merged_into_id,
        "requester": {
            "id": ticket.requester.id,
            "name": ticket.requester.name,
            "email": ticket.requester.email,
            "company": ticket.requester.company,
        },
        "team": {"id": ticket.team.id, "name": ticket.team.name}
        if ticket.team
        else None,
        "assignee": {"id": ticket.assignee.id, "name": ticket.assignee.full_name}
        if ticket.assignee
        else None,
        "channel": {
            "id": ticket.channel.id,
            "name": ticket.channel.name,
            "type": ticket.channel.type.value,
        }
        if ticket.channel
        else None,
        "tags": [link.tag.name for link in ticket.tag_links],
        "followers": [
            {"id": follower.user.id, "name": follower.user.full_name}
            for follower in ticket.followers
        ],
        "custom_fields": ticket.custom_fields_json,
        "metadata": ticket.metadata_json,
        "created_at": as_utc(ticket.created_at).isoformat()
        if ticket.created_at
        else None,
        "updated_at": as_utc(ticket.updated_at).isoformat()
        if ticket.updated_at
        else None,
        "first_response_due_at": as_utc(ticket.first_response_due_at).isoformat()
        if ticket.first_response_due_at
        else None,
        "next_response_due_at": as_utc(ticket.next_response_due_at).isoformat()
        if ticket.next_response_due_at
        else None,
        "resolution_due_at": as_utc(ticket.resolution_due_at).isoformat()
        if ticket.resolution_due_at
        else None,
        "first_responded_at": as_utc(ticket.first_responded_at).isoformat()
        if ticket.first_responded_at
        else None,
        "resolved_at": as_utc(ticket.resolved_at).isoformat()
        if ticket.resolved_at
        else None,
        "closed_at": as_utc(ticket.closed_at).isoformat() if ticket.closed_at else None,
        "overdue": overdue_state(ticket),
        "messages": [serialize_message(message) for message in messages],
    }


def get_ticket(db: Session, ticket_id: int) -> Ticket:
    ticket = db.scalar(
        select(Ticket)
        .where(Ticket.id == ticket_id, Ticket.deleted.is_(False))
        .options(
            joinedload(Ticket.requester),
            joinedload(Ticket.assignee),
            joinedload(Ticket.team),
            joinedload(Ticket.channel),
            joinedload(Ticket.sla).joinedload(SLA.business_hours),
            joinedload(Ticket.messages).joinedload(TicketMessage.author_user),
            joinedload(Ticket.messages).joinedload(TicketMessage.author_customer),
            joinedload(Ticket.messages).joinedload(TicketMessage.attachments),
            joinedload(Ticket.tag_links).joinedload(TicketTagLink.tag),
            joinedload(Ticket.followers).joinedload(TicketFollower.user),
            joinedload(Ticket.events),
        )
    )
    if not ticket:
        raise HTTPException(status_code=404, detail="Ticket not found")
    return ticket


def build_ticket_filters(
    stmt: Select[tuple[Ticket]],
    *,
    view: str | None,
    status_value: str | None,
    priority: str | None,
    search: str | None,
    user: User,
) -> Select[tuple[Ticket]]:
    if view == "mine":
        stmt = stmt.where(Ticket.assignee_id == user.id)
    elif view == "unassigned":
        stmt = stmt.where(Ticket.assignee_id.is_(None))
    elif view == "high_priority":
        stmt = stmt.where(
            Ticket.priority.in_([TicketPriority.HIGH, TicketPriority.URGENT])
        )
    elif view == "awaiting_customer":
        stmt = stmt.where(Ticket.status == TicketStatus.PENDING)
    elif view == "overdue":
        now = utcnow()
        stmt = stmt.where(
            or_(
                Ticket.first_response_due_at < now,
                Ticket.next_response_due_at < now,
                Ticket.resolution_due_at < now,
            )
        )
    if status_value:
        try:
            state = TicketStatus(status_value)
        except ValueError:
            raise HTTPException(status_code=422, detail="Unknown ticket status.")
        stmt = stmt.where(Ticket.status == state)
    if priority:
        try:
            level = TicketPriority(priority)
        except ValueError:
            raise HTTPException(status_code=422, detail="Unknown ticket priority.")
        stmt = stmt.where(Ticket.priority == level)
    if search:
        term = search.lower()
        stmt = stmt.where(
            or_(
                func.lower(Ticket.subject).contains(term, autoescape=True),
                Ticket.messages.any(
                    func.lower(TicketMessage.body).contains(term, autoescape=True)
                ),
                Ticket.requester.has(
                    func.lower(Customer.name).contains(term, autoescape=True)
                ),
                Ticket.requester.has(
                    func.lower(Customer.email).contains(term, autoescape=True)
                ),
            )
        )
    return stmt


def merge_tickets(
    db: Session,
    target: Ticket,
    source: Ticket,
    actor_user: User,
    request_id: str | None = None,
) -> Ticket:
    if actor_user.role not in {Role.INSTANCE_ADMIN, Role.SUPPORT_MANAGER}:
        raise HTTPException(status_code=403, detail="Ticket merges require a manager.")
    require_writable_ticket(target)
    require_writable_ticket(source)
    if source.id == target.id:
        raise HTTPException(status_code=400, detail="Cannot merge a ticket into itself")
    if source.requester_id != target.requester_id:
        raise HTTPException(
            status_code=409,
            detail="Tickets with different requesters cannot be merged; their conversations must remain separate.",
        )
    for message in list(source.messages):
        message.ticket = target
        for attachment in message.attachments:
            attachment.ticket_id = target.id
    for event in list(source.events):
        event.ticket = target
    existing = {link.tag.name for link in target.tag_links}
    for link in source.tag_links:
        if link.tag.name not in existing:
            target.tag_links.append(TicketTagLink(tag=link.tag))
    source.merged_into_id = target.id
    source.status = TicketStatus.CLOSED
    source.archived = True
    source.closed_at = utcnow()
    source.first_response_due_at = source.next_response_due_at = (
        source.resolution_due_at
    ) = None
    target.updated_at = utcnow()
    add_event(
        db,
        target,
        "ticket_merged",
        {"source_ticket_id": source.id},
        actor_user=actor_user,
    )
    audit(
        db,
        entity_type="ticket",
        entity_id=str(target.id),
        action="ticket_merged",
        details={"source_ticket_id": source.id},
        actor_user=actor_user,
        request_id=request_id,
    )
    return target


def split_ticket(
    db: Session,
    source: Ticket,
    message_ids: list[int],
    actor_user: User,
    request_id: str | None = None,
) -> Ticket:
    require_writable_ticket(source)
    if not can_reply_externally(actor_user):
        raise HTTPException(status_code=403, detail="This role cannot split tickets.")
    if (
        type(message_ids) is not list
        or not 1 <= len(message_ids) <= 100
        or any(type(value) is not int or value <= 0 for value in message_ids)
        or len(set(message_ids)) != len(message_ids)
    ):
        raise HTTPException(
            status_code=422, detail="Choose 1 to 100 unique message identifiers."
        )
    messages = [message for message in source.messages if message.id in message_ids]
    if len(messages) != len(message_ids):
        raise HTTPException(
            status_code=422,
            detail="Every selected message must belong to the source ticket.",
        )
    new_ticket = Ticket(
        number=next_ticket_number(db),
        subject=f"Split from #{source.number}: {source.subject}"[:255],
        requester_id=source.requester_id,
        status=TicketStatus.NEW,
        priority=source.priority,
        team_id=source.team_id,
        assignee_id=source.assignee_id,
        channel_id=source.channel_id,
        sla_id=source.sla_id,
    )
    db.add(new_ticket)
    db.flush()
    for message in messages:
        message.ticket = new_ticket
        for attachment in message.attachments:
            attachment.ticket_id = new_ticket.id
    source.updated_at = utcnow()
    refresh_sla(new_ticket, db)
    add_event(
        db,
        source,
        "ticket_split",
        {"new_ticket_id": new_ticket.id},
        actor_user=actor_user,
    )
    add_event(
        db,
        new_ticket,
        "ticket_created_from_split",
        {"source_ticket_id": source.id},
        actor_user=actor_user,
    )
    audit(
        db,
        entity_type="ticket",
        entity_id=str(new_ticket.id),
        action="ticket_split_created",
        details={"source_ticket_id": source.id},
        actor_user=actor_user,
        request_id=request_id,
    )
    return new_ticket


def report_summary(db: Session, user: User) -> dict:
    visible = and_(Ticket.deleted.is_(False), ticket_visibility_clause(user))
    total_open = (
        db.scalar(
            select(func.count())
            .select_from(Ticket)
            .where(
                Ticket.status.not_in(
                    [TicketStatus.RESOLVED, TicketStatus.CLOSED, TicketStatus.SPAM]
                ),
                visible,
            )
        )
        or 0
    )
    closed = (
        db.scalar(
            select(func.count())
            .select_from(Ticket)
            .where(
                Ticket.status.in_([TicketStatus.RESOLVED, TicketStatus.CLOSED]), visible
            )
        )
        or 0
    )
    by_channel_rows = db.execute(
        select(Channel.type, func.count(Ticket.id))
        .select_from(Ticket)
        .join(Channel, Ticket.channel_id == Channel.id, isouter=True)
        .where(visible)
        .group_by(Channel.type)
    ).all()
    overdue = (
        db.scalar(
            select(func.count())
            .select_from(Ticket)
            .where(
                visible,
                Ticket.status.not_in(
                    [TicketStatus.RESOLVED, TicketStatus.CLOSED, TicketStatus.SPAM]
                ),
                or_(
                    Ticket.first_response_due_at < utcnow(),
                    Ticket.next_response_due_at < utcnow(),
                    Ticket.resolution_due_at < utcnow(),
                ),
            )
        )
        or 0
    )
    avg_first = db.scalar(
        select(
            func.avg(
                (
                    func.strftime("%s", Ticket.first_responded_at)
                    - func.strftime("%s", Ticket.created_at)
                )
                / 60.0
            )
        ).where(Ticket.first_responded_at.is_not(None), visible)
    )
    avg_resolution = db.scalar(
        select(
            func.avg(
                (
                    func.strftime("%s", Ticket.resolved_at)
                    - func.strftime("%s", Ticket.created_at)
                )
                / 60.0
            )
        ).where(Ticket.resolved_at.is_not(None), visible)
    )
    agent_activity = db.execute(
        select(User.full_name, func.count(TicketMessage.id))
        .join(TicketMessage, TicketMessage.author_user_id == User.id)
        .join(Ticket, TicketMessage.ticket_id == Ticket.id)
        .where(TicketMessage.kind == MessageKind.PUBLIC, visible)
        .group_by(User.id, User.full_name)
        .order_by(func.count(TicketMessage.id).desc())
    ).all()
    return {
        "open_backlog": total_open,
        "closed_tickets": closed,
        "overdue_tickets": overdue,
        "average_first_response_minutes": round(float(avg_first or 0), 2),
        "average_resolution_minutes": round(float(avg_resolution or 0), 2),
        "ticket_volume_by_channel": [
            {"channel": channel.value if channel else "unknown", "count": count}
            for channel, count in by_channel_rows
        ],
        "agent_activity": [
            {"agent": name, "public_replies": count} for name, count in agent_activity
        ],
    }


def csv_cell(value):
    if isinstance(value, str) and (
        value.lstrip(" \t\r\n").startswith(("=", "+", "-", "@"))
        or value[:1] in ("\t", "\r", "\n")
    ):
        return "'" + value
    return value


def report_csv(db: Session, user: User) -> str:
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(
        [
            "ticket_number",
            "subject",
            "status",
            "priority",
            "requester",
            "team",
            "assignee",
            "created_at",
        ]
    )
    tickets = db.scalars(
        select(Ticket)
        .options(
            joinedload(Ticket.requester),
            joinedload(Ticket.team),
            joinedload(Ticket.assignee),
        )
        .where(Ticket.deleted.is_(False), ticket_visibility_clause(user))
        .order_by(Ticket.id)
    ).all()
    for ticket in tickets:
        writer.writerow(
            [
                csv_cell(value)
                for value in [
                    ticket.number,
                    ticket.subject,
                    ticket.status.value,
                    ticket.priority.value,
                    ticket.requester.email,
                    ticket.team.name if ticket.team else "",
                    ticket.assignee.full_name if ticket.assignee else "",
                    ticket.created_at.isoformat(),
                ]
            ]
        )
    return output.getvalue()


def create_ticket(
    db: Session,
    *,
    requester: Customer,
    subject: str,
    body: str,
    channel: Channel | None,
    actor_user: User | None = None,
    actor_customer: Customer | None = None,
    team_id: int | None = None,
    priority: TicketPriority = TicketPriority.NORMAL,
    tags: list[str] | None = None,
    metadata: dict | None = None,
    request_id: str | None = None,
) -> Ticket:
    values = contracts.validate(
        {
            "requester_id": requester.id,
            "subject": subject,
            "body": body,
            "team_id": team_id,
            "priority": priority.value,
            "tags": tags or [],
        },
        contracts.TicketCreate,
    )
    subject, body, tags = values["subject"], values["body"], values["tags"]
    sla = default_sla(db)
    selected_team_id = (
        team_id
        if team_id is not None
        else (channel.routing_team_id if channel else None)
    )
    assignment(db, selected_team_id, None, actor_user)
    ticket = Ticket(
        number=next_ticket_number(db),
        subject=subject,
        requester_id=requester.id,
        status=TicketStatus.NEW,
        priority=priority,
        team_id=selected_team_id,
        channel_id=channel.id if channel else None,
        sla_id=sla.id,
        metadata_json=metadata or {},
        last_customer_message_at=utcnow(),
    )
    db.add(ticket)
    db.flush()
    if tags:
        sync_ticket_tags(db, ticket, tags)
    refresh_sla(ticket, db)
    db.add(
        TicketMessage(
            ticket_id=ticket.id,
            author_user_id=actor_user.id if actor_user else None,
            author_customer_id=actor_customer.id if actor_customer else None,
            kind=MessageKind.PUBLIC,
            body=body.strip(),
            metadata_json=metadata or {},
            created_at=utcnow(),
        )
    )
    add_event(
        db,
        ticket,
        "ticket_created",
        {"channel": channel.type.value if channel else "manual"},
        actor_user=actor_user,
    )
    audit(
        db,
        entity_type="ticket",
        entity_id=str(ticket.id),
        action="ticket_created",
        details={"channel_id": channel.id if channel else None},
        actor_user=actor_user,
        actor_customer=actor_customer,
        request_id=request_id,
    )
    run_automations(
        db, AutomationEvent.ON_CREATE, ticket, actor_user=actor_user, context_text=body
    )
    return ticket


def get_or_create_customer(
    db: Session,
    name: str,
    email: str,
    phone: str | None = None,
    company: str | None = None,
) -> Customer:
    if not isinstance(name, str) or not 1 <= len(name.strip()) <= 255:
        raise HTTPException(
            status_code=422, detail="Customer name must contain 1 to 255 characters."
        )
    if (
        not isinstance(email, str)
        or not 3 <= len(email.strip()) <= 255
        or not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", email.strip())
    ):
        raise HTTPException(
            status_code=422, detail="Supply a valid customer email address."
        )
    for label, value, limit in [("phone", phone, 64), ("company", company, 255)]:
        if value is not None and (not isinstance(value, str) or len(value) > limit):
            raise HTTPException(
                status_code=422,
                detail=f"Customer {label} exceeds its allowed length or has the wrong type.",
            )
    if any(
        ord(char) < 32 or ord(char) == 127
        for char in name + email + (phone or "") + (company or "")
    ):
        raise HTTPException(
            status_code=422,
            detail="Customer fields must not contain control characters.",
        )
    name, email = name.strip(), email.strip().lower()
    customer = db.scalar(select(Customer).where(func.lower(Customer.email) == email))
    if customer:
        # Intake is not permission to edit an existing customer's profile.
        return customer
    customer = Customer(name=name, email=email, phone=phone, company=company)
    db.add(customer)
    db.flush()
    return customer


def merge_customers(
    db: Session,
    target: Customer,
    source: Customer,
    actor_user: User,
    request_id: str | None = None,
) -> Customer:
    if actor_user.role not in {Role.INSTANCE_ADMIN, Role.SUPPORT_MANAGER}:
        raise HTTPException(
            status_code=403, detail="Customer merges require a manager."
        )
    if target.id == source.id:
        raise HTTPException(
            status_code=400, detail="Cannot merge a customer into itself"
        )
    if db.scalar(select(User.id).where(User.customer_id.in_([source.id, target.id]))):
        raise HTTPException(
            status_code=409,
            detail="A customer has a linked sign-in identity. Use a separate verified identity migration; this merge cannot transfer account access.",
        )
    target.version += 1
    for ticket in source.tickets:
        ticket.requester_id = target.id
    for user in db.scalars(select(User).where(User.customer_id == source.id)).all():
        user.customer_id = target.id
    source.email = f"merged+{source.id}@invalid.local"
    source.notes = (
        (source.notes or "").strip() + f"\nMerged into customer {target.id}"
    ).strip()
    audit(
        db,
        entity_type="customer",
        entity_id=str(target.id),
        action="customer_merged",
        details={"source_customer_id": source.id},
        actor_user=actor_user,
        request_id=request_id,
    )
    return target


def seed_database(db: Session) -> None:
    if db.scalar(select(User).limit(1)):
        return
    org = Organization(name="Acme Holdings")
    db.add(org)
    bh = BusinessHours(
        name="Default Business Hours",
        timezone="America/Los_Angeles",
        schedule_json=DEFAULT_SCHEDULE,
    )
    db.add(bh)
    db.flush()
    team = Team(
        name="Support", description="Primary support team", business_hours_id=bh.id
    )
    db.add(team)
    db.flush()
    email_channel = Channel(
        name="Email",
        type=ChannelType.EMAIL,
        address="support@example.com",
        routing_team_id=team.id,
        signature="Thanks,\nSupport",
    )
    portal_channel = Channel(
        name="Portal", type=ChannelType.WEB, routing_team_id=team.id
    )
    api_channel = Channel(name="API", type=ChannelType.API, routing_team_id=team.id)
    db.add_all([email_channel, portal_channel, api_channel])
    db.flush()
    db.add(
        SLA(
            name="Default SLA",
            first_response_minutes=60,
            next_response_minutes=240,
            resolution_minutes=480,
            business_hours_id=bh.id,
            pause_on_pending=True,
            pause_on_hold=True,
            is_default=True,
        )
    )
    customer = Customer(
        name="Pat Customer",
        email="customer@example.com",
        phone="555-0100",
        company="Acme",
        organization_id=org.id,
    )
    db.add(customer)
    db.flush()
    users = [
        User(
            full_name="Admin User",
            email="admin@example.com",
            password_hash=hash_password("changeme123"),
            role=Role.INSTANCE_ADMIN,
        ),
        User(
            full_name="Manager User",
            email="manager@example.com",
            password_hash=hash_password("changeme123"),
            role=Role.SUPPORT_MANAGER,
        ),
        User(
            full_name="Agent User",
            email="agent@example.com",
            password_hash=hash_password("changeme123"),
            role=Role.AGENT,
        ),
        User(
            full_name="Light Agent",
            email="lightagent@example.com",
            password_hash=hash_password("changeme123"),
            role=Role.LIGHT_AGENT,
        ),
        User(
            full_name="Pat Customer",
            email="customer@example.com",
            password_hash=hash_password("changeme123"),
            role=Role.CUSTOMER,
            customer_id=customer.id,
        ),
        User(
            full_name="Integration Bot",
            email="integration@example.com",
            password_hash=hash_password("changeme123"),
            role=Role.INTEGRATION_BOT,
        ),
    ]
    db.add_all(users)
    db.flush()
    db.add_all(
        [
            TeamMember(team_id=team.id, user_id=users[1].id),
            TeamMember(team_id=team.id, user_id=users[2].id),
            TeamMember(team_id=team.id, user_id=users[3].id),
        ]
    )
    canned = CannedReply(
        title="Acknowledgement",
        body_template="Hi {{ customer_name }},\n\nWe received ticket #{{ ticket_number }} and will follow up shortly.",
    )
    macro = Macro(
        name="Close with thanks",
        description="Resolve ticket and tag as completed",
        actions_json={"set_status": "resolved", "add_tags": ["completed"]},
    )
    automation = AutomationRule(
        name="Escalate urgent billing",
        event=AutomationEvent.ON_CREATE,
        enabled=True,
        position=1,
        conditions_json={"text_match": "billing"},
        actions_json={"set_priority": "high", "add_tags": ["billing"]},
    )
    report = Report(name="Default Summary", definition_json={"kind": "summary"})
    webhook = Webhook(
        name="Audit Sink",
        target_url="https://example.invalid/webhook",
        secret_hash=hash_token("demo-webhook-secret"),
        event_types_json=["ticket.created"],
        enabled=False,
    )
    db.add_all([canned, macro, automation, report, webhook])
    db.flush()
    db.add(
        ApiToken(
            user_id=users[5].id,
            label="default-ingestion",
            token_hash=hash_token("integration-token-demo"),
        )
    )
    demo_ticket = create_ticket(
        db,
        requester=customer,
        subject="Need help with billing address",
        body="Our billing address is wrong in the invoice portal.",
        channel=email_channel,
        actor_customer=customer,
        team_id=team.id,
    )
    demo_ticket.assignee_id = users[2].id
    demo_ticket.status = TicketStatus.OPEN
    demo_ticket.priority = TicketPriority.HIGH
    db.add(TicketFollower(ticket_id=demo_ticket.id, user_id=users[3].id))
    sync_ticket_tags(db, demo_ticket, ["billing", "vip"])
    add_event(
        db,
        demo_ticket,
        "assignment_changed",
        {"assignee_id": users[2].id},
        actor_user=users[1],
    )
    audit(
        db,
        entity_type="seed",
        entity_id="bootstrap",
        action="seed_completed",
        details={"ticket_id": demo_ticket.id},
        actor_user=users[0],
    )
