"""Explicit local account setup. Normal server startup never creates known logins."""

import argparse
from getpass import getpass

from sqlalchemy import select
from sqlalchemy.orm import Session

from app import config, contracts
from app.db import Base, engine
from app.migrations import migrate_database
from app.models import User, Role
from app.security import hash_password
from app.services import default_sla, seed_database


def initialize(db, mode, *, name=None, email=None, password=None):
    if db.scalar(select(User.id).limit(1)):
        raise ValueError(
            "Accounts already exist. Setup preserves them and refuses to reset passwords or add demo identities."
        )
    if mode == "demo":
        if any(
            db.execute(select(table).limit(1)).first()
            for table in Base.metadata.sorted_tables
        ):
            raise ValueError(
                "Demo setup requires an empty database. Choose a new HELPDESK_DATA_DIR; existing records were preserved."
            )
        seed_database(db)
        return
    if mode != "owner":
        raise ValueError("Unknown setup mode.")
    identity = contracts.validate(
        {"name": name, "email": email}, contracts.CustomerBody
    )
    if (
        not isinstance(password, str)
        or not 12 <= len(password) <= 128
        or len(password.encode("utf-8")) > 512
    ):
        raise ValueError(
            "Choose a password of 12 to 128 characters, at most 512 UTF-8 bytes."
        )
    user = User(
        full_name=identity["name"],
        email=identity["email"],
        password_hash=hash_password(password),
        role=Role.INSTANCE_ADMIN,
    )
    db.add(user)
    default_sla(db)
    db.flush()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="mode", required=True)
    owner = sub.add_parser("owner")
    owner.add_argument("--name", required=True)
    owner.add_argument("--email", required=True)
    demo = sub.add_parser("demo")
    demo.add_argument("--acknowledge-local-only", action="store_true", required=True)
    args = parser.parse_args()
    password = None
    if args.mode == "owner":
        password = getpass("New owner password: ")
        if password != getpass("Repeat password: "):
            parser.error("Passwords do not match.")
    config.prepare_storage()
    migrate_database(engine, config.DATA_DIR / "migration-backups")
    try:
        with Session(engine) as db:
            db.connection().exec_driver_sql("BEGIN IMMEDIATE")
            initialize(
                db,
                args.mode,
                name=getattr(args, "name", None),
                email=getattr(args, "email", None),
                password=password,
            )
            db.commit()
    except (ValueError, contracts.ContractError) as error:
        parser.exit(1, str(error) + "\n")
    print(
        f"{args.mode.title()} setup completed in {config.DATA_DIR}. Start the server on 127.0.0.1."
    )
    if args.mode == "demo":
        print(
            "Known demo credentials are listed in the learning guide. Keep this disposable dataset local."
        )


if __name__ == "__main__":
    main()
