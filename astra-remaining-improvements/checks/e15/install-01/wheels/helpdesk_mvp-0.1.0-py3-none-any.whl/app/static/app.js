const page = document.body.dataset.page;

async function fetchJSON(url, options = {}) {
  let response;
  try {
    response = await fetch(url, {
      ...options,
      headers: {
        ...(options.body instanceof FormData
          ? {}
          : { "Content-Type": "application/json" }),
        ...(options.headers || {}),
      },
      credentials: "same-origin",
    });
  } catch (_) {
    throw new Error(
      "Connection interrupted. The server may have saved your change. Your draft remains here; review the latest record before submitting again.",
    );
  }
  if (!response.ok) {
    let detail = `Request failed: ${response.status}`;
    try {
      const payload = await response.json();
      detail =
        typeof payload.detail === "string"
          ? payload.detail
          : JSON.stringify(payload.detail || payload);
    } catch (_) {
      detail = `Request failed: ${response.status}. Keep your draft and review the server state.`;
    }
    const error = new Error(detail);
    error.status = response.status;
    throw error;
  }
  const contentType = response.headers.get("content-type") || "";
  try {
    return await (contentType.includes("application/json")
      ? response.json()
      : response.text());
  } catch (_) {
    throw new Error(
      "The response could not be read. Your change may have been saved. Retain your draft and review the record.",
    );
  }
}

const dirtyForms = new Set();
window.addEventListener("beforeunload", (event) => {
  if (dirtyForms.size) {
    event.preventDefault();
    event.returnValue = "";
  }
});
document.addEventListener("click", (event) => {
  if (
    event.target.closest("a[href]") &&
    dirtyForms.size &&
    !confirm("Leave this page and discard the unsaved drafts?")
  )
    event.preventDefault();
});

function watchForm(form) {
  form.addEventListener("input", () => dirtyForms.add(form));
  form.addEventListener("change", () => dirtyForms.add(form));
}

function clearDraft(form) {
  form.reset();
  dirtyForms.delete(form);
}

function bindForm(form, submit, flash) {
  watchForm(form);
  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    if (form.dataset.busy === "true") return;
    const controls = [...form.elements];
    // Capture values before disabling controls: disabled fields are omitted by FormData.
    const data = new FormData(form);
    const prior = controls.map((control) => control.disabled);
    form.dataset.busy = "true";
    form.setAttribute("aria-busy", "true");
    controls.forEach((control) => {
      control.disabled = true;
    });
    try {
      await submit(form, data);
    } catch (error) {
      showFlash(flash, error.message, true);
    } finally {
      controls.forEach((control, index) => {
        control.disabled = prior[index];
      });
      delete form.dataset.busy;
      form.removeAttribute("aria-busy");
    }
  });
}

function objectFromData(data) {
  return Object.fromEntries(
    [...data.entries()].filter(([, value]) => value !== ""),
  );
}

function creationKey(form) {
  if (!form.dataset.operationKey)
    form.dataset.operationKey = crypto.randomUUID();
  return form.dataset.operationKey;
}

function formToObject(form) {
  const data = new FormData(form);
  return Object.fromEntries(
    [...data.entries()].filter(([, value]) => value !== ""),
  );
}

function $(selector) {
  return document.querySelector(selector);
}

function textElement(tag, value, className) {
  const element = document.createElement(tag);
  element.textContent = String(value ?? "");
  if (className) element.className = className;
  return element;
}

function labeledValue(label, value) {
  const element = document.createElement("div");
  element.append(
    textElement("strong", label),
    document.createElement("br"),
    document.createTextNode(String(value ?? "")),
  );
  return element;
}

function showFlash(selector, message, isError = false) {
  const node = $(selector);
  if (!node) return;
  node.textContent = message;
  node.style.color = isError ? "var(--danger)" : "var(--muted)";
}

async function login(email, password, flashSelector = "#login-flash") {
  try {
    const payload = await fetchJSON("/auth/login", {
      method: "POST",
      body: JSON.stringify({ email, password }),
    });
    dirtyForms.delete($("#login-form"));
    dirtyForms.delete($("#portal-login-form"));
    showFlash(flashSelector, `Signed in as ${payload.user.full_name}`);
    if (payload.user.role === "customer") {
      window.location.href = "/portal";
      return;
    }
    window.location.href =
      payload.user.role === "instance_admin" ||
      payload.user.role === "support_manager"
        ? "/admin"
        : "/app";
  } catch (error) {
    showFlash(flashSelector, error.message, true);
  }
}

async function logout() {
  if (dirtyForms.size && !confirm("Sign out and discard the unsaved drafts?"))
    return;
  try {
    await fetchJSON("/auth/logout", { method: "POST" });
  } catch (error) {
    alert(error.message);
    return;
  }
  dirtyForms.clear();
  window.location.href = "/";
}

function renderTicketList(items, container, onSelect, activeId) {
  container.innerHTML = "";
  if (!items.length) {
    container.innerHTML = `<div class="list-item">No tickets match the current filter.</div>`;
    return;
  }
  items.forEach((ticket) => {
    const node = document.createElement("button");
    node.type = "button";
    node.className = `list-item ${ticket.id === activeId ? "active" : ""}`;
    node.append(
      textElement("strong", `#${ticket.number} ${ticket.subject}`),
      textElement(
        "div",
        `${ticket.requester.name} · ${ticket.status} · ${ticket.priority}`,
      ),
      textElement(
        "small",
        `${ticket.team ? ticket.team.name : "No team"}${ticket.overdue ? " · overdue" : ""}`,
      ),
    );
    node.addEventListener("click", () => onSelect(ticket.id));
    container.appendChild(node);
  });
}

function renderMessages(messages, container) {
  container.innerHTML = "";
  if (!messages.length) {
    container.innerHTML = `<div class="message-card">No conversation yet.</div>`;
    return;
  }
  messages.forEach((message) => {
    const node = document.createElement("article");
    node.className = "message-card";
    if (["public_reply", "internal_note", "system"].includes(message.kind))
      node.classList.add(message.kind);
    const body = textElement("p", message.body);
    body.style.whiteSpace = "pre-wrap";
    node.append(
      textElement("strong", message.author_name),
      textElement(
        "small",
        `${new Date(message.created_at).toLocaleString()} · ${message.kind}`,
      ),
      body,
    );
    if (message.attachments?.length) {
      const links = textElement("div", "Attachments: ");
      message.attachments.forEach((item) => {
        const link = textElement("a", `${item.filename} (${item.size} bytes)`);
        link.href = `/attachments/${item.id}`;
        link.download = item.filename;
        links.append(link, document.createTextNode(" "));
      });
      node.append(links);
    }
    container.appendChild(node);
  });
}

function renderTicketDetail(ticket, state) {
  $("#ticket-title").textContent = `#${ticket.number} ${ticket.subject}`;
  $("#ticket-status-chip").textContent =
    `${ticket.status}${ticket.overdue ? " · overdue" : ""}`;
  $("#ticket-meta").replaceChildren(
    labeledValue(
      "Requester",
      `${ticket.requester.name} (${ticket.requester.email})`,
    ),
    labeledValue("Team", ticket.team ? ticket.team.name : "Unassigned"),
    labeledValue("Assignee", ticket.assignee ? ticket.assignee.name : "Nobody"),
    labeledValue(
      "SLA",
      `First due: ${ticket.first_response_due_at ? new Date(ticket.first_response_due_at).toLocaleString() : "n/a"}`,
    ),
  );
  if (!dirtyForms.has($("#ticket-update-form"))) {
    $("#ticket-update-form [name=subject]").value = ticket.subject;
    $("#ticket-update-form [name=status]").value = ticket.status;
    $("#ticket-update-form [name=priority]").value = ticket.priority;
    $("#ticket-team").value = ticket.team?.id ?? "";
    $("#ticket-assignee").value = ticket.assignee?.id ?? "";
  }
  renderMessages(ticket.messages, $("#ticket-messages"));
  state.activeTicketId = ticket.id;
  state.version = ticket.version;
}

function fillSelect(select, items, placeholder) {
  const empty = textElement("option", placeholder);
  empty.value = "";
  select.replaceChildren(empty);
  items.forEach((item) => {
    const option = document.createElement("option");
    option.value = item.id;
    option.textContent = item.name;
    select.appendChild(option);
  });
}

async function initIndex() {
  $("#logout-button")?.addEventListener("click", logout);
  bindForm(
    $("#login-form"),
    async (form, data) => {
      const values = objectFromData(data);
      await login(values.email, values.password);
    },
    "#login-flash",
  );
}

async function initWorkspace(portal = false) {
  const state = {
    activeTicketId: null,
    version: null,
    page: 1,
    listSequence: 0,
    detailSequence: 0,
    busy: false,
  };
  const prefix = portal ? "/portal/tickets" : "/tickets";
  const flash = portal ? "#portal-flash" : "#workspace-flash";
  const list = $(portal ? "#portal-ticket-list" : "#ticket-list");
  const editForms = portal
    ? [$("#portal-reply-form")]
    : [$("#ticket-update-form"), $("#reply-form"), $("#note-form")];
  editForms.forEach((form) => {
    form.addEventListener("input", () => {
      state.detailSequence++;
    });
    form.addEventListener("change", () => {
      state.detailSequence++;
    });
  });
  let reviewed = null;
  const reportError = (error) => showFlash(flash, error.message, true);
  function hasDraft() {
    return editForms.some((form) => dirtyForms.has(form));
  }
  function paint(ticket) {
    if (portal) {
      $("#portal-ticket-title").textContent =
        `#${ticket.number} ${ticket.subject}`;
      renderMessages(ticket.messages, $("#portal-ticket-detail"));
      state.activeTicketId = ticket.id;
      state.version = ticket.version;
    } else renderTicketDetail(ticket, state);
    reviewed = null;
    $("#latest-review").hidden = true;
    $("#accept-latest").hidden = true;
  }
  async function loadTicket(id, force = false) {
    if (state.busy) return;
    if (
      !force &&
      hasDraft() &&
      !confirm("Discard unsaved ticket drafts and open this conversation?")
    )
      return;
    const sequence = ++state.detailSequence;
    const ticket = await fetchJSON(`${prefix}/${id}`);
    if (sequence !== state.detailSequence) return;
    if (!force) editForms.forEach(clearDraft);
    paint(ticket);
  }
  async function loadTickets() {
    const sequence = ++state.listSequence;
    const params = new URLSearchParams({
      page: String(state.page),
      page_size: "20",
    });
    if (!portal) {
      params.set("view", $("#queue-view").value);
      params.set("search", $("#ticket-search").value.trim());
    }
    try {
      const data = await fetchJSON(`${prefix}?${params}`);
      if (sequence !== state.listSequence) return;
      renderTicketList(
        data.items,
        list,
        (id) => loadTicket(id).catch(reportError),
        state.activeTicketId,
      );
      $("#ticket-page").textContent =
        `Page ${state.page} - ${data.total ?? data.items.length} tickets`;
      $("#ticket-prev").disabled = state.page <= 1;
      $("#ticket-next").disabled = !data.has_more;
      if (!state.activeTicketId && data.items.length)
        await loadTicket(data.items[0].id);
    } catch (error) {
      if (portal && error.status === 401) {
        list.replaceChildren(
          textElement("p", "Sign in to view your ticket history."),
        );
        $("#ticket-prev").disabled = true;
        $("#ticket-next").disabled = true;
      } else reportError(error);
    }
  }
  $("#ticket-prev").addEventListener("click", () => {
    if (state.page > 1) {
      state.page--;
      loadTickets();
    }
  });
  $("#ticket-next").addEventListener("click", () => {
    state.page++;
    loadTickets();
  });
  $("#review-latest").addEventListener("click", async () => {
    if (!state.activeTicketId || state.busy) return;
    try {
      const id = state.activeTicketId;
      const latest = await fetchJSON(`${prefix}/${id}`);
      if (id !== state.activeTicketId) return;
      reviewed = latest;
      $("#latest-review").textContent = JSON.stringify(latest, null, 2);
      $("#latest-review").hidden = false;
      $("#accept-latest").hidden = false;
      showFlash(
        flash,
        "Review the latest fields and conversation above, especially whether your previous message was already saved. Your draft and its old version remain unchanged until you acknowledge this review.",
      );
    } catch (error) {
      reportError(error);
    }
  });
  $("#accept-latest").addEventListener("click", () => {
    if (!reviewed || state.busy) return;
    if (
      !confirm(
        "I reviewed the latest record and checked whether an uncertain submission was already saved. Keep my drafts and use this reviewed version?",
      )
    )
      return;
    paint(reviewed);
    showFlash(
      flash,
      "Latest version accepted. Review your retained drafts before saving.",
    );
  });
  async function mutate(form, data, suffix, method) {
    if (!state.activeTicketId) throw new Error("Select a ticket first.");
    if (state.busy)
      throw new Error("Wait for the current ticket operation to finish.");
    state.busy = true;
    try {
      const ticket = await fetchJSON(
        `${prefix}/${state.activeTicketId}${suffix}`,
        {
          method,
          headers: { "If-Match": String(state.version) },
          body: data,
        },
      );
      clearDraft(form);
      paint(ticket);
      showFlash(flash, "Saved. The conversation shows the accepted result.");
    } finally {
      state.busy = false;
    }
    await loadTickets();
  }
  if (!portal) {
    const bootstrap = await fetchJSON("/data/bootstrap");
    fillSelect($("#ticket-team"), bootstrap.teams, "No team");
    fillSelect(
      $("#ticket-assignee"),
      bootstrap.users.filter((u) => u.role !== "light_agent"),
      "No assignee",
    );
    const customers = await fetchJSON("/customers?page_size=100");
    fillSelect(
      $("#create-requester"),
      customers.items,
      "Select customer (search to narrow results)",
    );
    let customerSequence = 0,
      customerTimer;
    $("#create-customer-search").addEventListener("input", () => {
      const sequence = ++customerSequence;
      clearTimeout(customerTimer);
      customerTimer = setTimeout(async () => {
        try {
          const data = await fetchJSON(
            `/customers?page_size=100&search=${encodeURIComponent($("#create-customer-search").value.trim())}`,
          );
          if (sequence === customerSequence)
            fillSelect(
              $("#create-requester"),
              data.items,
              "Select a matching customer",
            );
        } catch (value) {
          reportError(value);
        }
      }, 250);
    });
    if (bootstrap.me.role === "light_agent") {
      $("#staff-create-panel").hidden = true;
      $("#ticket-update-form").hidden = true;
      $("#reply-form").hidden = true;
    }
    $("#delete-ticket").hidden = ![
      "instance_admin",
      "support_manager",
    ].includes(bootstrap.me.role);
    $("#queue-view").addEventListener("change", () => {
      state.page = 1;
      loadTickets();
    });
    let timer;
    $("#ticket-search").addEventListener("input", () => {
      state.listSequence++;
      clearTimeout(timer);
      timer = setTimeout(() => {
        state.page = 1;
        loadTickets();
      }, 250);
    });
    bindForm(
      $("#ticket-update-form"),
      async (form, data) => {
        const payload = objectFromData(data);
        payload.team_id = payload.team_id ? Number(payload.team_id) : null;
        payload.assignee_id = payload.assignee_id
          ? Number(payload.assignee_id)
          : null;
        await mutate(form, JSON.stringify(payload), "", "PATCH");
      },
      flash,
    );
    bindForm(
      $("#reply-form"),
      (form, data) => mutate(form, data, "/reply", "POST"),
      flash,
    );
    bindForm(
      $("#note-form"),
      (form, data) => mutate(form, data, "/note", "POST"),
      flash,
    );
    $("#delete-ticket").addEventListener("click", async () => {
      if (!state.activeTicketId || state.busy) return;
      if (
        !confirm(
          "Delete this ticket from active work? Its conversation and receipts are retained for staff recovery. Unsaved drafts will be discarded after success.",
        )
      )
        return;
      state.busy = true;
      try {
        await fetchJSON(`${prefix}/${state.activeTicketId}`, {
          method: "DELETE",
          headers: { "If-Match": String(state.version) },
        });
        editForms.forEach(clearDraft);
        state.activeTicketId = null;
        state.version = null;
        $("#ticket-title").textContent = "Select a ticket";
        $("#ticket-messages").replaceChildren();
        $("#ticket-meta").replaceChildren();
        showFlash(
          flash,
          "Ticket removed from active work. Its stored history is retained.",
        );
      } catch (error) {
        reportError(error);
      } finally {
        state.busy = false;
      }
      await loadTickets();
    });
  } else {
    bindForm(
      $("#portal-reply-form"),
      (form, data) => mutate(form, data, "/reply", "POST"),
      flash,
    );
    if ($("#portal-login-form"))
      bindForm(
        $("#portal-login-form"),
        async (form, data) => {
          const values = objectFromData(data);
          await login(values.email, values.password, flash);
        },
        flash,
      );
  }
  const createForm = $(portal ? "#portal-create-form" : "#staff-create-form");
  bindForm(
    createForm,
    async (form, data) => {
      const payload = portal ? data : objectFromData(data);
      if (!portal) payload.requester_id = Number(payload.requester_id);
      const ticket = await fetchJSON(prefix, {
        method: "POST",
        body: portal ? payload : JSON.stringify(payload),
        headers: { "Idempotency-Key": creationKey(form) },
      });
      clearDraft(form);
      delete form.dataset.operationKey;
      showFlash(
        flash,
        `Submitted ticket #${ticket.number}${ticket.duplicate ? " (existing submission)" : ""}.`,
      );
      await loadTickets();
    },
    flash,
  );
  $(portal ? "#portal-new-operation" : "#staff-new-operation").addEventListener(
    "click",
    () => {
      if (createForm.dataset.busy === "true") return;
      if (
        !confirm(
          "Discard this draft and begin a separate submission? If the previous result was uncertain, review ticket history with staff first to avoid creating a duplicate.",
        )
      )
        return;
      clearDraft(createForm);
      delete createForm.dataset.operationKey;
      showFlash(flash, "Ready for a new submission.");
    },
  );
  $("#logout-button")?.addEventListener("click", logout);
  await loadTickets();
}

async function initStaff() {
  return initWorkspace(false);
}

function renderSimpleList(items, container, render) {
  container.innerHTML = "";
  items.forEach((item) => {
    const node = document.createElement("div");
    node.className = "list-item";
    node.append(...render(item));
    container.appendChild(node);
  });
}

const resourceForms = {
  customers: {
    label: "customer",
    help: "Profiles hold contact details. Linked sign-in identities require a separate verified email-change workflow.",
    fields: [
      ["name", "Name", "text", true],
      ["email", "Email", "email", true],
      ["phone", "Phone (optional)", "text"],
      ["company", "Company (optional)", "text"],
      ["notes", "Staff notes (optional)", "textarea"],
    ],
  },
  teams: {
    label: "team",
    help: "Team members must be active staff. Reassign tickets before removing their assigned agent.",
    fields: [
      ["name", "Name", "text", true],
      ["description", "Description (optional)", "textarea"],
      [
        "business_hours_id",
        "Business hours (blank uses default)",
        "business-hours",
      ],
      [
        "member_ids",
        "Members (Ctrl/Cmd to select several)",
        "users",
        false,
        [],
      ],
    ],
  },
  channels: {
    label: "channel",
    help: "Incoming requests use the channel's routing team. This local project records requests; it does not send email or call an external provider.",
    fields: [
      ["name", "Name", "text", true],
      ["type", "Type", ["web", "email", "api", "chat"], true, "web"],
      ["address", "Address (optional)", "text"],
      ["signature", "Signature (optional)", "textarea"],
      ["routing_team_id", "Routing team (optional)", "teams"],
      ["config", "Additional settings (JSON object)", "json", false, {}],
    ],
  },
  slas: {
    label: "service level agreement",
    help: "Durations are business minutes, including zero. The existing default policy remains required. Updating a policy does not rewrite deadlines already stored on tickets.",
    fields: [
      ["name", "Name", "text", true],
      [
        "business_hours_id",
        "Business hours (blank uses default)",
        "business-hours",
      ],
      ["first_response_minutes", "First response minutes", "number", true, 60],
      ["next_response_minutes", "Next response minutes", "number", true, 240],
      ["resolution_minutes", "Resolution minutes", "number", true, 480],
      ["pause_on_pending", "Pause while pending", "checkbox", false, true],
      ["pause_on_hold", "Pause while on hold", "checkbox", false, true],
      ["is_default", "Default policy", "checkbox", false, false],
    ],
  },
  "business-hours": {
    label: "business calendar",
    help: 'Use an IANA timezone, such as UTC or America/Los_Angeles. Schedule keys 0 to 6 mean Monday to Sunday. Example: {"0":[["09:00","12:00"],["13:00","17:00"]]}. Windows cannot overlap or cross midnight.',
    fields: [
      ["name", "Name", "text", true],
      ["timezone", "Timezone", "text", true, "UTC"],
      [
        "schedule",
        "Weekly schedule (JSON object)",
        "json",
        true,
        {
          0: [["09:00", "17:00"]],
          1: [["09:00", "17:00"]],
          2: [["09:00", "17:00"]],
          3: [["09:00", "17:00"]],
          4: [["09:00", "17:00"]],
        },
      ],
    ],
  },
  automations: {
    label: "automation",
    help: 'Rules run in position order. Example condition: {"text_match":"billing"}. Example action: {"set_priority":"high","add_tags":["billing"]}. Unknown fields are rejected. A canned reply is recorded only when a full staff user triggers the rule.',
    fields: [
      ["name", "Name", "text", true],
      [
        "event",
        "Event",
        ["on_create", "on_update", "on_reply", "on_time_elapsed"],
        true,
        "on_create",
      ],
      ["enabled", "Enabled", "checkbox", false, false],
      ["position", "Position", "number", true, 0],
      ["conditions", "Conditions (JSON object)", "json", true, {}],
      [
        "actions",
        "Actions (JSON object)",
        "json",
        true,
        { set_priority: "high" },
      ],
    ],
  },
  "canned-replies": {
    label: "canned reply",
    help: "Available placeholders: {{ customer_name }}, {{ ticket_number }}, and {{ ticket_subject }}. Replies are stored locally; outbound delivery is not implemented.",
    fields: [
      ["title", "Title", "text", true],
      ["body_template", "Reply template", "textarea", true],
    ],
  },
};

async function initAdmin() {
  const state = {
    kind: "customers",
    item: null,
    page: 1,
    sequence: 0,
    busy: false,
    reviewed: null,
  };
  const form = $("#resource-form");
  form.addEventListener("input", () => {
    state.sequence++;
  });
  form.addEventListener("change", () => {
    state.sequence++;
  });
  const flash = "#admin-flash";
  const error = (value) => showFlash(flash, value.message, true);
  const lookups = {};
  async function refreshLookups() {
    const [teams, calendars, bootstrap] = await Promise.all([
      fetchJSON("/manage/teams?page_size=100"),
      fetchJSON("/manage/business-hours?page_size=100"),
      fetchJSON("/data/bootstrap"),
    ]);
    lookups.teams = teams.items;
    lookups["business-hours"] = calendars.items;
    lookups.users = bootstrap.users;
  }
  function resetReview() {
    state.reviewed = null;
    $("#resource-latest").hidden = true;
    $("#resource-accept").hidden = true;
  }
  function syncBusyControls() {
    for (const control of form.elements) control.disabled = state.busy;
    $("#resource-kind").disabled = state.busy;
    $("#resource-new").disabled = state.busy;
    $("#resource-delete").disabled = state.busy || !state.item;
    $("#resource-review").disabled = state.busy || !state.item;
    $("#resource-accept").disabled = state.busy;
  }
  function setBusy(busy) {
    state.busy = busy;
    syncBusyControls();
  }
  function renderForm(item = null) {
    state.item = item;
    resetReview();
    dirtyForms.delete(form);
    const spec = resourceForms[state.kind];
    $("#resource-title").textContent =
      `${item ? "Edit" : "New"} ${spec.label}${item ? ` - version ${item.version}` : ""}`;
    $("#resource-help").textContent = spec.help;
    $("#resource-fields").replaceChildren();
    for (const [
      name,
      label,
      type,
      required = false,
      fallback = null,
    ] of spec.fields) {
      const wrap = textElement("label", label);
      let input;
      const value = item ? item[name] : fallback;
      if (Array.isArray(type) || lookups[type]) {
        input = document.createElement("select");
        if (name === "member_ids") input.multiple = true;
        if (!required && !input.multiple) {
          const blank = textElement("option", "None / default");
          blank.value = "";
          input.append(blank);
        }
        const options = Array.isArray(type)
          ? type.map((value) => ({ id: value, name: value }))
          : lookups[type];
        for (const option of options) {
          const node = textElement("option", option.name);
          node.value = option.id;
          node.selected = input.multiple
            ? (value || []).includes(option.id)
            : String(value) === String(option.id);
          input.append(node);
        }
        // Keep an existing reference selectable even if it is outside the first lookup page.
        if (
          !input.multiple &&
          value != null &&
          !options.some((option) => String(option.id) === String(value))
        ) {
          const current = textElement("option", `Current record #${value}`);
          current.value = value;
          current.selected = true;
          input.append(current);
        }
      } else if (type === "textarea" || type === "json") {
        input = document.createElement("textarea");
        input.rows = type === "json" ? 6 : 4;
        input.value =
          type === "json"
            ? JSON.stringify(value ?? {}, null, 2)
            : (value ?? "");
        input.maxLength = name === "notes" ? 5000 : 20000;
      } else {
        input = document.createElement("input");
        input.type = type;
        if (type === "checkbox") input.checked = Boolean(value);
        else input.value = value ?? "";
        if (type === "number") {
          input.min = "0";
          input.max = name === "position" ? "10000" : "525600";
          input.step = "1";
        } else input.maxLength = name === "phone" ? 64 : 255;
      }
      input.name = name;
      input.required = required;
      input.setAttribute("aria-label", label);
      wrap.append(input);
      $("#resource-fields").append(wrap);
    }
    syncBusyControls();
  }
  function payload(data) {
    const result = {};
    for (const [name, , type] of resourceForms[state.kind].fields) {
      const value = data.get(name);
      if (type === "checkbox") result[name] = data.has(name);
      else if (name === "member_ids")
        result[name] = data.getAll(name).map(Number);
      else if (type === "number" || lookups[type])
        result[name] = value === "" || value === null ? null : Number(value);
      else if (type === "json") result[name] = JSON.parse(value || "{}");
      else result[name] = value === "" ? null : value;
    }
    return result;
  }
  function mayLeave() {
    return (
      !state.busy &&
      (!dirtyForms.has(form) ||
        confirm("Discard this unsaved administration draft?"))
    );
  }
  async function selectRecord(id) {
    if (!mayLeave()) return;
    const kind = state.kind;
    const sequence = ++state.sequence;
    try {
      const item = await fetchJSON(`/manage/${kind}/${id}`);
      if (kind === state.kind && sequence === state.sequence) renderForm(item);
    } catch (value) {
      error(value);
    }
  }
  async function load() {
    const kind = state.kind;
    const sequence = ++state.sequence;
    const params = new URLSearchParams({
      page: String(state.page),
      page_size: "20",
      search: $("#resource-search").value.trim(),
    });
    try {
      const data = await fetchJSON(`/manage/${kind}?${params}`);
      if (kind !== state.kind || sequence !== state.sequence) return;
      $("#resource-list").replaceChildren();
      for (const item of data.items) {
        const button = textElement(
          "button",
          `${item.name || item.title} - version ${item.version}`,
          "list-item",
        );
        button.type = "button";
        button.addEventListener("click", () => selectRecord(item.id));
        $("#resource-list").append(button);
      }
      if (!data.items.length)
        $("#resource-list").append(textElement("p", "No matching records."));
      $("#resource-page").textContent =
        `Page ${state.page} - ${data.total} records`;
      $("#resource-prev").disabled = state.page <= 1;
      $("#resource-next").disabled = !data.has_more;
    } catch (value) {
      error(value);
    }
  }
  $("#resource-kind").addEventListener("change", async () => {
    if (!mayLeave()) {
      $("#resource-kind").value = state.kind;
      return;
    }
    state.kind = $("#resource-kind").value;
    state.page = 1;
    state.sequence++;
    $("#resource-search").value = "";
    renderForm();
    await load();
  });
  $("#resource-new").addEventListener("click", () => {
    if (mayLeave()) {
      state.sequence++;
      renderForm();
    }
  });
  $("#resource-prev").addEventListener("click", () => {
    if (state.page > 1) {
      state.page--;
      load();
    }
  });
  $("#resource-next").addEventListener("click", () => {
    state.page++;
    load();
  });
  let timer;
  $("#resource-search").addEventListener("input", () => {
    state.sequence++;
    clearTimeout(timer);
    timer = setTimeout(() => {
      state.page = 1;
      load();
    }, 250);
  });
  bindForm(
    form,
    async (form, data) => {
      if (state.busy) return;
      setBusy(true);
      try {
        const item = state.item;
        const result = await fetchJSON(
          `/manage/${state.kind}${item ? `/${item.id}` : ""}`,
          {
            method: item ? "PUT" : "POST",
            headers: item ? { "If-Match": String(item.version) } : {},
            body: JSON.stringify(payload(data)),
          },
        );
        renderForm(result);
        showFlash(flash, "Saved. The form shows the accepted record.");
        await refreshLookups();
        await load();
      } finally {
        setBusy(false);
      }
    },
    flash,
  );
  $("#resource-review").addEventListener("click", async () => {
    if (!state.item || state.busy) return;
    const kind = state.kind,
      id = state.item.id;
    try {
      const latest = await fetchJSON(`/manage/${kind}/${id}`);
      if (state.kind !== kind || state.item?.id !== id) return;
      state.reviewed = latest;
      $("#resource-latest").textContent = JSON.stringify(latest, null, 2);
      $("#resource-latest").hidden = false;
      $("#resource-accept").hidden = false;
      showFlash(
        flash,
        "Compare the latest record with your retained draft. Saving will replace all editable fields.",
      );
    } catch (value) {
      error(value);
    }
  });
  $("#resource-accept").addEventListener("click", () => {
    if (!state.reviewed || state.busy) return;
    if (
      !confirm(
        "Use the reviewed version with your retained draft? A save replaces all editable fields.",
      )
    )
      return;
    state.item = state.reviewed;
    resetReview();
    $("#resource-title").textContent =
      `Edit ${resourceForms[state.kind].label} - version ${state.item.version}`;
    showFlash(flash, "Reviewed version accepted. Your draft remains unsaved.");
  });
  $("#resource-delete").addEventListener("click", async () => {
    if (!state.item || state.busy) return;
    if (
      !confirm(
        `Delete this ${resourceForms[state.kind].label}? Referenced records are protected. Unsaved changes will be discarded after success.`,
      )
    )
      return;
    setBusy(true);
    try {
      await fetchJSON(`/manage/${state.kind}/${state.item.id}`, {
        method: "DELETE",
        headers: { "If-Match": String(state.item.version) },
      });
      renderForm();
      showFlash(flash, "Record deleted.");
      await load();
    } catch (value) {
      error(value);
    } finally {
      setBusy(false);
    }
  });
  async function report() {
    try {
      const summary = await fetchJSON("/reports/summary");
      $("#report-summary").replaceChildren(
        labeledValue("Open backlog", summary.open_backlog),
        labeledValue("Closed tickets", summary.closed_tickets),
        labeledValue("Overdue tickets", summary.overdue_tickets),
        labeledValue(
          "First response",
          `${summary.average_first_response_minutes} minutes`,
        ),
        labeledValue(
          "Resolution",
          `${summary.average_resolution_minutes} minutes`,
        ),
      );
    } catch (value) {
      error(value);
    }
  }
  $("#reports-refresh").addEventListener("click", report);
  $("#logout-button").addEventListener("click", logout);
  await refreshLookups();
  renderForm();
  await load();
  await report();
}

async function initPortal() {
  return initWorkspace(true);
}

const boot = {
  index: initIndex,
  staff: initStaff,
  admin: initAdmin,
  portal: initPortal,
};
boot[page]?.().catch((error) => {
  console.error(error);
  showFlash("#admin-flash", error.message, true);
  showFlash("#workspace-flash", error.message, true);
  showFlash("#login-flash", error.message, true);
  showFlash("#portal-flash", error.message, true);
});
