"""Read-only reconciliation of attachment records and local files; never deletes."""

import json
from pathlib import Path

from sqlalchemy import select
from sqlalchemy.orm import Session

from app import config
from app.db import engine
from app.models import Attachment


def inspect_storage(db, root):
    root = Path(root).resolve()
    referenced = set()
    issues = []
    for attachment in db.scalars(select(Attachment)).all():
        path = Path(attachment.storage_path).resolve()
        if path.parent != root:
            issues.append(
                {"id": attachment.id, "problem": "outside configured upload directory"}
            )
            continue
        referenced.add(path)
        if not path.is_file():
            issues.append({"id": attachment.id, "problem": "missing file"})
        elif path.stat().st_size != attachment.size:
            issues.append({"id": attachment.id, "problem": "size mismatch"})
    orphans = [
        str(path) for path in root.glob("*.blob") if path.resolve() not in referenced
    ]
    return {
        "record_issues": issues,
        "unreferenced_files": orphans,
        "action": "No files or database records changed.",
    }


def main():
    if not (config.DATA_DIR / "helpdesk.db").is_file():
        raise SystemExit("No existing database to inspect.")
    with Session(engine) as db:
        print(json.dumps(inspect_storage(db, config.UPLOAD_DIR), indent=2))


if __name__ == "__main__":
    main()
